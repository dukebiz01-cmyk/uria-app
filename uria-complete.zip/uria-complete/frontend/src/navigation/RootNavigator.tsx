import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { useAuthStore } from '../store/auth.store';
import { useUserStore } from '../store/user.store';
import { useTokenRefresh } from '../hooks/useTokenRefresh';
import { AuthNavigator } from './AuthNavigator';
import { AppNavigator } from './AppNavigator';
import { LoadingOverlay } from '../components/common/LoadingOverlay';
import { colors } from '../constants/colors';

// ─── 딥링크 설정 ──────────────────────────────────────────────────────────────

const linking = {
  prefixes: ['uria://', 'https://app.uria.app'],
  config: {
    screens: {
      App: {
        screens: {
          Chat: {
            screens: {
              ChatRoom: 'chat/:roomId',
            },
          },
          Signals: {
            screens: {
              SignalDetail: 'signal/:signalId',
            },
          },
        },
      },
    },
  },
};

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const RootNavigator: React.FC = () => {
  const { isAuthenticated, isLoading: authLoading, hydrate } = useAuthStore();
  const fetchProfile = useUserStore((s) => s.fetchProfile);
  const profile = useUserStore((s) => s.profile);
  const [isHydrating, setIsHydrating] = useState(true);

  // 토큰 자동 갱신
  useTokenRefresh();

  // 앱 시작 시 저장된 토큰 복원
  useEffect(() => {
    hydrate().finally(() => setIsHydrating(false));
  }, [hydrate]);

  // 인증 완료 시 프로필 로드
  useEffect(() => {
    if (isAuthenticated && !profile) {
      fetchProfile();
    }
  }, [isAuthenticated, profile, fetchProfile]);

  if (isHydrating || authLoading) {
    return <LoadingOverlay visible message="로딩 중..." />;
  }

  // 온보딩 미완료 체크 (프로필에 닉네임 없으면 온보딩으로)
  const isOnboardingRequired =
    isAuthenticated && profile && !profile.nickname;

  return (
    <NavigationContainer
      linking={linking}
      theme={{
        dark: true,
        colors: {
          primary: colors.primary,
          background: colors.bg,
          card: colors.surface,
          text: colors.text,
          border: colors.border,
          notification: colors.accent,
        },
      }}
    >
      {isAuthenticated ? (
        <AppNavigator isOnboardingRequired={!!isOnboardingRequired} />
      ) : (
        <AuthNavigator />
      )}
    </NavigationContainer>
  );
};
