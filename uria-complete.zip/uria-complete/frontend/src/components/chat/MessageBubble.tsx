import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import FastImage from 'react-native-fast-image';
import { ChatMessage } from '../../types/api.types';
import { colors } from '../../constants/colors';
import { formatChatTime } from '../../utils/format';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface MessageBubbleProps {
  message: ChatMessage;
  isMine: boolean;
  showTime?: boolean;
}

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isMine,
  showTime = true,
}) => {
  const isSystem = message.type === 'system';

  // 시스템 메시지
  if (isSystem) {
    return (
      <View style={styles.systemContainer}>
        <Text style={styles.systemText}>{message.content}</Text>
      </View>
    );
  }

  // MOMENT 요청 메시지
  if (message.type === 'moment_request') {
    return (
      <View style={[styles.momentCard, isMine ? styles.momentCardMine : styles.momentCardOther]}>
        <Text style={styles.momentIcon}>🌙</Text>
        <Text style={styles.momentTitle}>MOMENT 요청</Text>
        <Text style={styles.momentDesc}>{message.content}</Text>
        <Text style={styles.bubbleTime}>{formatChatTime(message.createdAt)}</Text>
      </View>
    );
  }

  // 이미지 메시지
  if (message.type === 'image' && message.imageUrl) {
    return (
      <View style={[styles.row, isMine ? styles.rowMine : styles.rowOther]}>
        <View style={[styles.imageBubble, isMine ? styles.bubbleMine : styles.bubbleOther]}>
          <FastImage
            source={{ uri: message.imageUrl }}
            style={styles.imageContent}
            resizeMode={FastImage.resizeMode.cover}
          />
        </View>
        {showTime && (
          <Text style={[styles.bubbleTime, isMine ? styles.timeRight : styles.timeLeft]}>
            {formatChatTime(message.createdAt)}
            {isMine && message.isRead && <Text style={styles.readMark}> 읽음</Text>}
          </Text>
        )}
      </View>
    );
  }

  // 텍스트 메시지
  return (
    <View style={[styles.row, isMine ? styles.rowMine : styles.rowOther]}>
      <View style={[styles.bubble, isMine ? styles.bubbleMine : styles.bubbleOther]}>
        <Text style={[styles.messageText, isMine ? styles.textMine : styles.textOther]}>
          {message.content}
        </Text>
      </View>
      {showTime && (
        <Text style={[styles.bubbleTime, isMine ? styles.timeRight : styles.timeLeft]}>
          {isMine && message.isRead && <Text style={styles.readMark}>읽음 </Text>}
          {formatChatTime(message.createdAt)}
        </Text>
      )}
    </View>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  row: {
    flexDirection: 'column',
    marginVertical: 3,
    marginHorizontal: 16,
    maxWidth: '80%',
  },
  rowMine: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  rowOther: { alignSelf: 'flex-start', alignItems: 'flex-start' },

  bubble: {
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
    maxWidth: '100%',
  },
  bubbleMine: {
    backgroundColor: colors.primary,
    borderBottomRightRadius: 4,
  },
  bubbleOther: {
    backgroundColor: colors.surface,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },

  messageText: { fontSize: 15, lineHeight: 21 },
  textMine: { color: colors.white },
  textOther: { color: colors.text },

  bubbleTime: {
    fontSize: 10,
    color: colors.textFaint,
    marginTop: 3,
  },
  timeRight: { textAlign: 'right' },
  timeLeft: { textAlign: 'left' },
  readMark: { color: colors.teal, fontSize: 10 },

  imageBubble: { borderRadius: 14, overflow: 'hidden' },
  imageContent: { width: 200, height: 200 },

  systemContainer: {
    alignSelf: 'center',
    marginVertical: 8,
    paddingHorizontal: 14,
    paddingVertical: 6,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 12,
  },
  systemText: {
    fontSize: 12,
    color: colors.textFaint,
    textAlign: 'center',
  },

  momentCard: {
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    gap: 4,
    maxWidth: '70%',
    borderWidth: 1,
    borderColor: colors.teal,
  },
  momentCardMine: { alignSelf: 'flex-end', backgroundColor: colors.tealAlpha10 },
  momentCardOther: { alignSelf: 'flex-start', backgroundColor: colors.tealAlpha10 },
  momentIcon: { fontSize: 24 },
  momentTitle: { fontSize: 14, fontWeight: '700', color: colors.teal },
  momentDesc: { fontSize: 12, color: colors.textMuted, textAlign: 'center' },
});
