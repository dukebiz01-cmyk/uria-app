/**
 * useWebSocket — 글로벌 Signal 알림용 WebSocket
 * GAP1 수정: 채팅은 useChatRoomSocket (별도 훅) 사용
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { useAuthStore } from '../store/auth.store';
import { useSignalStore } from '../store/signal.store';
import { config } from '../constants/config';

export type WsStatus = 'connecting' | 'connected' | 'disconnected' | 'error';

export function useWebSocket() {
  const accessToken = useAuthStore((s) => s.accessToken);
  const addReceivedSignal = useSignalStore((s) => s.addReceivedSignal);
  const updateSignalStatus = useSignalStore((s) => s.updateSignalStatus);

  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const manualClose = useRef(false);
  const [status, setStatus] = useState<WsStatus>('disconnected');

  const connect = useCallback(() => {
    if (!accessToken || wsRef.current?.readyState === WebSocket.OPEN) return;
    setStatus('connecting');

    // ✅ GAP1 수정: 글로벌 WS는 Signal 알림 전용
    // 채팅 메시지는 ChatRoomScreen의 useChatRoomSocket 사용
    const url = `${config.WS_BASE_URL}/ws/notifications?token=${encodeURIComponent(accessToken)}`;
    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => { retryRef.current = 0; setStatus('connected'); };

    ws.onmessage = (e) => {
      try {
        const parsed = JSON.parse(e.data as string);
        switch (parsed.type) {
          case 'signal_received':
            addReceivedSignal(parsed.data);
            break;
          case 'signal_updated':
            updateSignalStatus(parsed.data.id, parsed.data.status);
            break;
          case 'pong':
            break;
        }
      } catch {}
    };

    ws.onerror = () => setStatus('error');
    ws.onclose = () => {
      wsRef.current = null;
      if (manualClose.current) { setStatus('disconnected'); return; }
      const delay = Math.min(config.WS_INITIAL_RETRY_DELAY * 2 ** retryRef.current, config.WS_MAX_RETRY_DELAY);
      if (retryRef.current < config.WS_MAX_RETRIES) {
        retryRef.current++;
        setStatus('connecting');
        timerRef.current = setTimeout(connect, delay);
      } else {
        setStatus('error');
      }
    };
  }, [accessToken, addReceivedSignal, updateSignalStatus]);

  const disconnect = useCallback(() => {
    manualClose.current = true;
    if (timerRef.current) clearTimeout(timerRef.current);
    wsRef.current?.close();
    wsRef.current = null;
    setStatus('disconnected');
  }, []);

  const reconnect = useCallback(() => {
    retryRef.current = 0;
    manualClose.current = false;
    disconnect();
    setTimeout(connect, 100);
  }, [connect, disconnect]);

  const send = useCallback((type: string, data?: unknown) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, data }));
    }
  }, []);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s: AppStateStatus) => {
      if (s === 'active' && status !== 'connected') { manualClose.current = false; retryRef.current = 0; connect(); }
      else if (s === 'background') disconnect();
    });
    return () => sub.remove();
  }, [connect, disconnect, status]);

  useEffect(() => {
    manualClose.current = false;
    retryRef.current = 0;
    if (accessToken) connect(); else disconnect();
    return () => { manualClose.current = true; timerRef.current && clearTimeout(timerRef.current); wsRef.current?.close(); };
  }, [accessToken]);

  return { status, send, reconnect };
}

/**
 * useChatRoomSocket — 채팅방 전용 WebSocket (GAP1 수정)
 * ChatRoomScreen에서 roomId 전달 시 사용
 */
export function useChatRoomSocket(roomId: string) {
  const accessToken = useAuthStore((s) => s.accessToken);
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);

  const connect = useCallback(() => {
    if (!accessToken || !roomId || wsRef.current?.readyState === WebSocket.OPEN) return;
    // ✅ 백엔드 chat.ws.js와 일치하는 URL 형식
    const url = `${config.WS_BASE_URL}/ws/chat/${roomId}?token=${encodeURIComponent(accessToken)}`;
    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => { setIsConnected(true); ws.send(JSON.stringify({ type: 'ping' })); };
    ws.onmessage = (e) => {
      const data = JSON.parse(e.data as string);
      if (data.type === 'message') setMessages((p) => [...p, data.message]);
    };
    ws.onclose = () => { setIsConnected(false); wsRef.current = null; setTimeout(connect, 2000); };
    ws.onerror = () => setIsConnected(false);
  }, [accessToken, roomId]);

  const sendMessage = useCallback((content: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'message', content }));
    }
  }, []);

  const markRead = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'read', timestamp: new Date().toISOString() }));
    }
  }, []);

  useEffect(() => {
    connect();
    return () => { wsRef.current?.close(); wsRef.current = null; };
  }, [connect]);

  return { messages, isConnected, sendMessage, markRead };
}
