import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PhoneScreen } from '../screens/auth/PhoneScreen';
import { OtpScreen } from '../screens/auth/OtpScreen';
import { GenderScreen } from '../screens/onboarding/GenderScreen';
import { ProfileScreen } from '../screens/onboarding/ProfileScreen';
import { PhotoScreen } from '../screens/onboarding/PhotoScreen';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

export type AuthStackParamList = {
  Phone: undefined;
  Otp: { phone: string };
  Gender: { userId: string };
  Profile: { userId: string; gender: 'male' | 'female' | 'other' };
  Photo: { userId: string };
};

const Stack = createNativeStackNavigator<AuthStackParamList>();

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const AuthNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
        contentStyle: { backgroundColor: '#0A0A0F' },
      }}
    >
      <Stack.Screen name="Phone" component={PhoneScreen} />
      <Stack.Screen name="Otp" component={OtpScreen} />
      <Stack.Screen name="Gender" component={GenderScreen} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="Photo" component={PhotoScreen} />
    </Stack.Navigator>
  );
};
