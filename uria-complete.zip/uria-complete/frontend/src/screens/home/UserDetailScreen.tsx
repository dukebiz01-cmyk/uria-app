import React, { useEffect, useState } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { usersApi } from '../../api/users.api';
import { signalsApi } from '../../api/signals.api';
import { passportApi } from '../../api/passport.api';
import { Avatar } from '../../components/common/Avatar';
import { TierBadge, CoinBadge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { Spinner } from '../../components/common/LoadingOverlay';
import { TrustScoreBar } from '../../components/passport/TrustScoreBar';
import { colors } from '../../constants/colors';
import { formatDistance, formatPercent } from '../../utils/format';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { UserProfile, Passport } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'UserDetail'>;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const UserDetailScreen: React.FC<Props> = ({ route, navigation }) => {
  const { userId } = route.params;

  const [user, setUser] = useState<UserProfile | null>(null);
  const [passport, setPassport] = useState<Passport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSignalForm, setShowSignalForm] = useState(false);
  const [signalMessage, setSignalMessage] = useState('');
  const [isSendingSignal, setIsSendingSignal] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const [userResult, passportResult] = await Promise.all([
          usersApi.getUserProfile(userId),
          passportApi.getUserPassport(userId),
        ]);
        setUser(userResult);
        setPassport(passportResult);
      } catch (e) {
        const err = parseApiError(e);
        Alert.alert('오류', getErrorMessage(err));
        navigation.goBack();
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [userId, navigation]);

  const handleSendSignal = async () => {
    if (!user) return;
    setIsSendingSignal(true);

    try {
      await signalsApi.sendSignal({
        toUserId: user.id,
        type: 'standard',
        message: signalMessage.trim() || undefined,
      });
      Alert.alert('SIGNAL 전송 완료', `${user.nickname}님에게 SIGNAL을 보냈습니다.`, [
        { text: '확인', onPress: () => navigation.goBack() },
      ]);
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('전송 실패', getErrorMessage(err));
    } finally {
      setIsSendingSignal(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  if (!user) return null;

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* 대표 사진 */}
        {user.photos[0] ? (
          <FastImage
            source={{ uri: user.photos[0] }}
            style={styles.heroPic}
            resizeMode={FastImage.resizeMode.cover}
          />
        ) : (
          <View style={styles.heroPlaceholder}>
            <Avatar uri={null} nickname={user.nickname} size="xl" />
          </View>
        )}

        {/* 기본 정보 */}
        <View style={styles.basicInfo}>
          <View style={styles.nameRow}>
            <Text style={styles.nickname}>{user.nickname}</Text>
            <Text style={styles.age}>{user.age}세</Text>
          </View>
          <View style={styles.badges}>
            <TierBadge tier={user.passportTier} size="md" />
            {user.distanceM !== undefined && (
              <Text style={styles.distance}>
                📍 {formatDistance(user.distanceM)}
              </Text>
            )}
            {user.isTonightMode && (
              <Text style={styles.tonightBadge}>🌙 TONIGHT</Text>
            )}
          </View>
          {user.bio ? (
            <Text style={styles.bio}>{user.bio}</Text>
          ) : null}
        </View>

        {/* 추가 사진 */}
        {user.photos.length > 1 && (
          <View style={styles.photoGrid}>
            {user.photos.slice(1).map((uri, i) => (
              <FastImage
                key={i}
                source={{ uri }}
                style={styles.photoItem}
                resizeMode={FastImage.resizeMode.cover}
              />
            ))}
          </View>
        )}

        {/* SCORE PASSPORT */}
        {passport && (
          <View style={styles.passportSection}>
            <Text style={styles.sectionTitle}>SCORE PASSPORT</Text>
            <TrustScoreBar score={passport.trustScore} tier={passport.tier} />

            <View style={styles.statsGrid}>
              {[
                { label: '응답률', value: formatPercent(passport.responseRate) },
                { label: '약속이행률', value: formatPercent(passport.punctualityRate) },
                { label: 'MOMENT', value: `${passport.momentCount}회` },
                {
                  label: '수락률',
                  value: formatPercent(passport.signalAcceptRate),
                },
              ].map((stat) => (
                <View key={stat.label} style={styles.statItem}>
                  <Text style={styles.statValue}>{stat.value}</Text>
                  <Text style={styles.statLabel}>{stat.label}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* SIGNAL 전송 폼 */}
        {showSignalForm && (
          <View style={styles.signalForm}>
            <Text style={styles.signalFormLabel}>메시지 (선택)</Text>
            <TextInput
              style={styles.signalInput}
              placeholder="짧은 메시지를 남겨보세요..."
              placeholderTextColor={colors.textFaint}
              value={signalMessage}
              onChangeText={setSignalMessage}
              maxLength={100}
              multiline
            />
          </View>
        )}

        {/* 액션 버튼 */}
        <View style={styles.actions}>
          {!showSignalForm ? (
            <>
              <Button
                title="⚡ SIGNAL 보내기"
                onPress={() => setShowSignalForm(true)}
                fullWidth
                size="lg"
              />
              <View style={styles.coinHint}>
                <CoinBadge amount={1} />
                <Text style={styles.coinHintText}>코인 1개 소모</Text>
              </View>
            </>
          ) : (
            <View style={styles.signalActions}>
              <Button
                title="취소"
                variant="outline"
                onPress={() => setShowSignalForm(false)}
                style={styles.signalCancelBtn}
              />
              <Button
                title="전송"
                onPress={handleSendSignal}
                isLoading={isSendingSignal}
                style={styles.signalSendBtn}
              />
            </View>
          )}
        </View>

        {/* 신고/차단 */}
        <View style={styles.reportRow}>
          <TouchableOpacity
            onPress={() => Alert.alert('차단', `${user.nickname}님을 차단하시겠습니까?`, [
              { text: '취소', style: 'cancel' },
              {
                text: '차단',
                style: 'destructive',
                onPress: () => usersApi.blockUser(user.id).then(() => navigation.goBack()),
              },
            ])}
          >
            <Text style={styles.reportText}>차단하기</Text>
          </TouchableOpacity>
          <Text style={styles.dot}>·</Text>
          <TouchableOpacity
            onPress={() => Alert.alert('신고', '이 유저를 신고하시겠습니까?', [
              { text: '취소', style: 'cancel' },
              {
                text: '신고',
                style: 'destructive',
                onPress: () =>
                  usersApi
                    .reportUser(user.id, 'inappropriate')
                    .then(() => navigation.goBack()),
              },
            ])}
          >
            <Text style={styles.reportText}>신고하기</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { paddingBottom: 40 },
  heroPic: { width: '100%', height: 340 },
  heroPlaceholder: {
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  basicInfo: { padding: 20, gap: 10 },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
  },
  nickname: { fontSize: 26, fontWeight: '800', color: colors.text },
  age: { fontSize: 18, color: colors.textMuted },
  badges: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flexWrap: 'wrap',
  },
  distance: { fontSize: 13, color: colors.textMuted },
  tonightBadge: { fontSize: 13, color: colors.teal, fontWeight: '600' },
  bio: {
    fontSize: 15,
    color: colors.textMuted,
    lineHeight: 22,
    marginTop: 4,
  },

  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 3,
    paddingHorizontal: 3,
  },
  photoItem: { width: '49.5%', aspectRatio: 1, borderRadius: 4 },

  passportSection: {
    margin: 16,
    padding: 20,
    backgroundColor: colors.surface,
    borderRadius: 20,
    gap: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.primary,
    letterSpacing: 1,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: { alignItems: 'center', gap: 4 },
  statValue: { fontSize: 18, fontWeight: '800', color: colors.text },
  statLabel: { fontSize: 11, color: colors.textFaint },

  signalForm: { marginHorizontal: 16, marginBottom: 12, gap: 8 },
  signalFormLabel: { fontSize: 13, color: colors.textMuted, fontWeight: '600' },
  signalInput: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: colors.border,
    padding: 14,
    fontSize: 14,
    color: colors.text,
    minHeight: 80,
    textAlignVertical: 'top',
  },

  actions: { marginHorizontal: 16, gap: 10 },
  coinHint: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center' },
  coinHintText: { fontSize: 12, color: colors.textFaint },
  signalActions: { flexDirection: 'row', gap: 10 },
  signalCancelBtn: { flex: 1 },
  signalSendBtn: { flex: 2 },

  reportRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    marginTop: 24,
  },
  reportText: { fontSize: 13, color: colors.textFaint },
  dot: { color: colors.textFaint },
});
