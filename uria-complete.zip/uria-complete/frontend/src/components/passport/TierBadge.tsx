import React from 'react';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors } from '../../constants/colors';
import { PassportTier } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface TierBadgeProps {
  tier: PassportTier;
  style?: ViewStyle;
  large?: boolean;
}

// ─── 티어 설정 ────────────────────────────────────────────────────────────────

const TIER_CONFIG: Record<
  PassportTier,
  { label: string; emoji: string; color: string; bg: string; desc: string }
> = {
  Starter: {
    label: 'Starter',
    emoji: '🌱',
    color: colors.textMuted,
    bg: colors.surfaceAlt,
    desc: '시작하는 단계',
  },
  Silver: {
    label: 'Silver',
    emoji: '🥈',
    color: '#C0C0C0',
    bg: 'rgba(192,192,192,0.12)',
    desc: '신뢰할 수 있는 유저',
  },
  Gold: {
    label: 'Gold',
    emoji: '🥇',
    color: colors.gold,
    bg: colors.goldAlpha10,
    desc: '높은 신뢰도',
  },
  Platinum: {
    label: 'Platinum',
    emoji: '💎',
    color: colors.teal,
    bg: colors.tealAlpha10,
    desc: '최고 등급 유저',
  },
};

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const TierBadgeLarge: React.FC<TierBadgeProps> = ({
  tier,
  style,
  large = false,
}) => {
  const conf = TIER_CONFIG[tier];

  if (!large) {
    return (
      <View
        style={[
          styles.small,
          { backgroundColor: conf.bg, borderColor: conf.color },
          style,
        ]}
      >
        <Text style={styles.smallEmoji}>{conf.emoji}</Text>
        <Text style={[styles.smallLabel, { color: conf.color }]}>
          {conf.label}
        </Text>
      </View>
    );
  }

  return (
    <View
      style={[
        styles.large,
        { backgroundColor: conf.bg, borderColor: conf.color },
        style,
      ]}
    >
      <Text style={styles.largeEmoji}>{conf.emoji}</Text>
      <Text style={[styles.largeLabel, { color: conf.color }]}>{conf.label}</Text>
      <Text style={styles.largeDesc}>{conf.desc}</Text>
    </View>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  small: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  smallEmoji: { fontSize: 12 },
  smallLabel: { fontSize: 11, fontWeight: '700' },

  large: {
    alignItems: 'center',
    gap: 6,
    padding: 20,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  largeEmoji: { fontSize: 40 },
  largeLabel: { fontSize: 22, fontWeight: '800' },
  largeDesc: { fontSize: 13, color: colors.textMuted },
});
