import React, { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { authApi } from '../../api/auth.api';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { colors } from '../../constants/colors';
import { toE164 } from '../../utils/format';
import { getErrorMessage, parseApiError } from '../../utils/errors';

// ─── 스키마 ───────────────────────────────────────────────────────────────────

const schema = z.object({
  phone: z
    .string()
    .min(10, '전화번호를 올바르게 입력해주세요.')
    .regex(/^01[016789]\d{7,8}$/, '올바른 휴대폰 번호를 입력해주세요. (예: 01012345678)'),
});

type FormData = z.infer<typeof schema>;

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AuthStackParamList, 'Phone'>;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const PhoneScreen: React.FC<Props> = ({ navigation }) => {
  const [isLoading, setIsLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { phone: '' },
  });

  const onSubmit = async (data: FormData) => {
    setIsLoading(true);
    try {
      const e164 = toE164(data.phone);
      await authApi.requestOtp({ phone: e164 });
      navigation.navigate('Otp', { phone: e164 });
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('오류', getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          {/* 헤더 */}
          <View style={styles.header}>
            <Text style={styles.logo}>URIA</Text>
            <Text style={styles.title}>전화번호로 시작하기</Text>
            <Text style={styles.subtitle}>
              인증번호를 발송합니다. 별도의 회원가입 없이 바로 시작할 수 있어요.
            </Text>
          </View>

          {/* 폼 */}
          <View style={styles.form}>
            <Controller
              control={control}
              name="phone"
              render={({ field: { onChange, value, onBlur } }) => (
                <Input
                  label="휴대폰 번호"
                  placeholder="01012345678"
                  keyboardType="phone-pad"
                  autoComplete="tel"
                  textContentType="telephoneNumber"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.phone?.message}
                  maxLength={11}
                />
              )}
            />

            <Button
              title="인증번호 받기"
              onPress={handleSubmit(onSubmit)}
              isLoading={isLoading}
              fullWidth
              size="lg"
              style={styles.submitBtn}
            />
          </View>

          {/* 약관 */}
          <Text style={styles.terms}>
            계속 진행하면{' '}
            <Text style={styles.termsLink}>이용약관</Text> 및{' '}
            <Text style={styles.termsLink}>개인정보처리방침</Text>에 동의하는 것으로 간주합니다.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  content: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
    gap: 32,
  },
  header: { gap: 12 },
  logo: {
    fontSize: 32,
    fontWeight: '900',
    color: colors.primary,
    letterSpacing: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textMuted,
    lineHeight: 21,
  },
  form: { gap: 20 },
  submitBtn: { marginTop: 8 },
  terms: {
    fontSize: 12,
    color: colors.textFaint,
    textAlign: 'center',
    lineHeight: 18,
  },
  termsLink: { color: colors.primary },
});
