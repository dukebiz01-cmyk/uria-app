import React from 'react';
import {
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { colors } from '../../constants/colors';
import { Signal } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface SignalActionSheetProps {
  visible: boolean;
  signal: Signal | null;
  onAccept: () => void;
  onDecline: () => void;
  onHold: () => void;
  onClose: () => void;
}

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const SignalActionSheet: React.FC<SignalActionSheetProps> = ({
  visible,
  signal,
  onAccept,
  onDecline,
  onHold,
  onClose,
}) => {
  if (!signal) return null;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <TouchableOpacity
        style={styles.backdrop}
        onPress={onClose}
        activeOpacity={1}
      >
        <View style={styles.sheet}>
          {/* 핸들 */}
          <View style={styles.handle} />

          <Text style={styles.title}>
            {signal.fromUser.nickname}님의 SIGNAL
          </Text>

          {signal.message ? (
            <View style={styles.messageBox}>
              <Text style={styles.messageText}>"{signal.message}"</Text>
            </View>
          ) : null}

          {/* 수락 */}
          <TouchableOpacity
            style={[styles.actionButton, styles.acceptButton]}
            onPress={onAccept}
          >
            <Text style={styles.acceptText}>💚 수락하기</Text>
            <Text style={styles.actionDesc}>채팅방이 열립니다</Text>
          </TouchableOpacity>

          {/* 보류 */}
          <TouchableOpacity
            style={[styles.actionButton, styles.holdButton]}
            onPress={onHold}
          >
            <Text style={styles.holdText}>⏳ 보류하기</Text>
            <Text style={styles.actionDesc}>나중에 결정할 수 있습니다</Text>
          </TouchableOpacity>

          {/* 거절 */}
          <TouchableOpacity
            style={[styles.actionButton, styles.declineButton]}
            onPress={onDecline}
          >
            <Text style={styles.declineText}>✕ 거절하기</Text>
          </TouchableOpacity>

          {/* 취소 */}
          <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
            <Text style={styles.cancelText}>닫기</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: colors.overlay,
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    paddingBottom: 40,
    gap: 12,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    alignSelf: 'center',
    marginBottom: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 4,
  },
  messageBox: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 12,
    padding: 14,
    marginBottom: 4,
  },
  messageText: {
    fontSize: 14,
    color: colors.textMuted,
    fontStyle: 'italic',
    textAlign: 'center',
    lineHeight: 20,
  },
  actionButton: {
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
    gap: 4,
  },
  acceptButton: { backgroundColor: colors.greenAlpha10 },
  holdButton: { backgroundColor: colors.goldAlpha10 },
  declineButton: { backgroundColor: colors.accentAlpha10 },
  acceptText: { fontSize: 16, fontWeight: '700', color: colors.green },
  holdText: { fontSize: 16, fontWeight: '700', color: colors.gold },
  declineText: { fontSize: 16, fontWeight: '700', color: colors.accent },
  actionDesc: { fontSize: 12, color: colors.textFaint },
  cancelButton: { alignItems: 'center', paddingVertical: 8, marginTop: 4 },
  cancelText: { fontSize: 15, color: colors.textMuted },
});
