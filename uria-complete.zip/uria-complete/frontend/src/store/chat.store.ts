import { create } from 'zustand';
import { chatApi } from '../api/chat.api';
import { ChatMessage, ChatRoom } from '../types/api.types';
import { parseApiError, getErrorMessage } from '../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface ChatState {
  rooms: ChatRoom[];
  roomsTotal: number;
  /** roomId → 메시지 배열 (최신 → 오래된 순, FlatList inverted용) */
  messages: Record<string, ChatMessage[]>;
  /** roomId → 더 불러올 메시지 있는지 */
  hasMoreMessages: Record<string, boolean>;
  /** roomId → 로딩 중 여부 */
  loadingMessages: Record<string, boolean>;
  isLoadingRooms: boolean;
  error: string | null;
}

interface ChatActions {
  fetchRooms: () => Promise<void>;
  fetchMessages: (roomId: string) => Promise<void>;
  loadMoreMessages: (roomId: string) => Promise<void>;
  sendMessage: (
    roomId: string,
    content: string,
    type?: ChatMessage['type'],
  ) => Promise<void>;
  /** WebSocket 수신 메시지 처리 */
  receiveMessage: (message: ChatMessage) => void;
  markRoomAsRead: (roomId: string) => void;
  updateReadStatus: (roomId: string, messageId: string) => void;
  reset: () => void;
}

type ChatStore = ChatState & ChatActions;

// ─── 스토어 ───────────────────────────────────────────────────────────────────

export const useChatStore = create<ChatStore>()((set, get) => ({
  rooms: [],
  roomsTotal: 0,
  messages: {},
  hasMoreMessages: {},
  loadingMessages: {},
  isLoadingRooms: false,
  error: null,

  fetchRooms: async () => {
    set({ isLoadingRooms: true, error: null });
    try {
      const result = await chatApi.getRooms();
      set({ rooms: result.items, roomsTotal: result.total, isLoadingRooms: false });
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err), isLoadingRooms: false });
    }
  },

  fetchMessages: async (roomId) => {
    set((state) => ({
      loadingMessages: { ...state.loadingMessages, [roomId]: true },
      error: null,
    }));
    try {
      const result = await chatApi.getMessages(roomId);
      // 최신 메시지 먼저 (inverted FlatList)
      const sorted = [...result.items].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
      set((state) => ({
        messages: { ...state.messages, [roomId]: sorted },
        hasMoreMessages: { ...state.hasMoreMessages, [roomId]: result.hasNext },
        loadingMessages: { ...state.loadingMessages, [roomId]: false },
      }));
    } catch (e) {
      const err = parseApiError(e);
      set((state) => ({
        error: getErrorMessage(err),
        loadingMessages: { ...state.loadingMessages, [roomId]: false },
      }));
    }
  },

  loadMoreMessages: async (roomId) => {
    const { messages, hasMoreMessages, loadingMessages } = get();
    if (loadingMessages[roomId] || !hasMoreMessages[roomId]) return;

    const roomMessages = messages[roomId] ?? [];
    // 가장 오래된 메시지 ID (배열 마지막)
    const oldestId = roomMessages[roomMessages.length - 1]?.id;

    set((state) => ({
      loadingMessages: { ...state.loadingMessages, [roomId]: true },
    }));

    try {
      const result = await chatApi.getMessages(roomId, oldestId);
      const sorted = [...result.items].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
      set((state) => ({
        messages: {
          ...state.messages,
          [roomId]: [...(state.messages[roomId] ?? []), ...sorted],
        },
        hasMoreMessages: { ...state.hasMoreMessages, [roomId]: result.hasNext },
        loadingMessages: { ...state.loadingMessages, [roomId]: false },
      }));
    } catch {
      set((state) => ({
        loadingMessages: { ...state.loadingMessages, [roomId]: false },
      }));
    }
  },

  sendMessage: async (roomId, content, type = 'text') => {
    try {
      const sent = await chatApi.sendMessage(roomId, { type, content });
      // 낙관적 업데이트: 상단(inverted list 기준 맨 앞)에 추가
      set((state) => ({
        messages: {
          ...state.messages,
          [roomId]: [sent, ...(state.messages[roomId] ?? [])],
        },
      }));
      // 방 목록 lastMessage 업데이트
      set((state) => ({
        rooms: state.rooms.map((r) =>
          r.id === roomId ? { ...r, lastMessage: sent, updatedAt: sent.createdAt } : r,
        ),
      }));
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err) });
      throw e;
    }
  },

  receiveMessage: (message) => {
    const { roomId } = message;
    set((state) => {
      const existing = state.messages[roomId] ?? [];
      // 중복 방지
      if (existing.some((m) => m.id === message.id)) return state;

      return {
        messages: { ...state.messages, [roomId]: [message, ...existing] },
        rooms: state.rooms.map((r) =>
          r.id === roomId
            ? {
                ...r,
                lastMessage: message,
                unreadCount: r.unreadCount + 1,
                updatedAt: message.createdAt,
              }
            : r,
        ),
      };
    });
  },

  markRoomAsRead: (roomId) => {
    set((state) => ({
      rooms: state.rooms.map((r) =>
        r.id === roomId ? { ...r, unreadCount: 0 } : r,
      ),
    }));
  },

  updateReadStatus: (roomId, messageId) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [roomId]: (state.messages[roomId] ?? []).map((m) =>
          m.id === messageId ? { ...m, isRead: true } : m,
        ),
      },
    }));
  },

  reset: () =>
    set({
      rooms: [],
      roomsTotal: 0,
      messages: {},
      hasMoreMessages: {},
      loadingMessages: {},
      error: null,
    }),
}));
