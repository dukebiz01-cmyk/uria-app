import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/ko';

dayjs.extend(relativeTime);
dayjs.locale('ko');

// ─── 날짜 ─────────────────────────────────────────────────────────────────────

export function formatDate(iso: string, template = 'YYYY.MM.DD'): string {
  return dayjs(iso).format(template);
}

export function formatRelativeTime(iso: string): string {
  return dayjs(iso).fromNow();
}

export function formatChatTime(iso: string): string {
  const d = dayjs(iso);
  const now = dayjs();
  if (d.isSame(now, 'day')) return d.format('HH:mm');
  if (d.isSame(now.subtract(1, 'day'), 'day')) return '어제';
  return d.format('M월 D일');
}

/**
 * SIGNAL 남은 시간 카운트다운 포맷
 * @param expiresAt ISO 8601 문자열
 * @returns "11:47:30" 형식 또는 "만료됨"
 */
export function formatSignalCountdown(expiresAt: string): string {
  const diffSeconds = dayjs(expiresAt).diff(dayjs(), 'second');
  if (diffSeconds <= 0) return '만료됨';

  const h = Math.floor(diffSeconds / 3600);
  const m = Math.floor((diffSeconds % 3600) / 60);
  const s = diffSeconds % 60;

  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

/**
 * MOMENT 타이머 포맷
 */
export function formatMomentTimer(seconds: number): string {
  if (seconds <= 0) return '00:00';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function calcAge(birthDate: string): number {
  return dayjs().diff(dayjs(birthDate), 'year');
}

// ─── 거리 ─────────────────────────────────────────────────────────────────────

/**
 * 미터 단위를 읽기 편한 문자열로 변환
 * 1000m 미만 → "350m", 이상 → "1.2km"
 */
export function formatDistance(meters: number): string {
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

// ─── 코인 ─────────────────────────────────────────────────────────────────────

export function formatCoin(amount: number): string {
  return `${amount.toLocaleString('ko-KR')}C`;
}

export function formatKRW(amount: number): string {
  return `₩${amount.toLocaleString('ko-KR')}`;
}

// ─── Trust Score ───────────────────────────────────────────────────────────────

export function formatTrustScore(score: number): string {
  return score.toFixed(1);
}

export function formatPercent(value: number): string {
  return `${Math.round(value)}%`;
}

// ─── 전화번호 ─────────────────────────────────────────────────────────────────

/**
 * "01012345678" → "+821012345678" (E.164)
 */
export function toE164(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('0')) {
    return `+82${digits.slice(1)}`;
  }
  if (digits.startsWith('82')) {
    return `+${digits}`;
  }
  return `+${digits}`;
}

/**
 * "+821012345678" → "010-1234-5678"
 */
export function formatPhoneDisplay(e164: string): string {
  const digits = e164.replace(/^\+82/, '0').replace(/\D/g, '');
  if (digits.length === 11) {
    return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
  }
  return digits;
}
