import AsyncStorage from '@react-native-async-storage/async-storage';
import { MMKV } from 'react-native-mmkv';

// ─── MMKV — 빠른 로컬 캐시 (동기) ────────────────────────────────────────────
export const mmkv = new MMKV({ id: 'uria-cache' });

export const cache = {
  set<T>(key: string, value: T): void {
    mmkv.set(key, JSON.stringify(value));
  },

  get<T>(key: string): T | null {
    const raw = mmkv.getString(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  },

  delete(key: string): void {
    mmkv.delete(key);
  },

  clear(): void {
    mmkv.clearAll();
  },

  has(key: string): boolean {
    return mmkv.contains(key);
  },
};

// ─── AsyncStorage — 민감 데이터 (비동기) ─────────────────────────────────────

const STORAGE_KEYS = {
  ACCESS_TOKEN: '@uria/access_token',
  REFRESH_TOKEN: '@uria/refresh_token',
  USER_ID: '@uria/user_id',
  ONBOARDING_DONE: '@uria/onboarding_done',
  TONIGHT_MODE: '@uria/tonight_mode',
} as const;

export type StorageKey = (typeof STORAGE_KEYS)[keyof typeof STORAGE_KEYS];

export const storage = {
  keys: STORAGE_KEYS,

  async setItem(key: StorageKey, value: string): Promise<void> {
    await AsyncStorage.setItem(key, value);
  },

  async getItem(key: StorageKey): Promise<string | null> {
    return AsyncStorage.getItem(key);
  },

  async removeItem(key: StorageKey): Promise<void> {
    await AsyncStorage.removeItem(key);
  },

  async clear(): Promise<void> {
    await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
  },

  // ── 토큰 편의 메서드 ──

  async saveTokens(accessToken: string, refreshToken: string): Promise<void> {
    await AsyncStorage.multiSet([
      [STORAGE_KEYS.ACCESS_TOKEN, accessToken],
      [STORAGE_KEYS.REFRESH_TOKEN, refreshToken],
    ]);
  },

  async getTokens(): Promise<{
    accessToken: string | null;
    refreshToken: string | null;
  }> {
    const [[, accessToken], [, refreshToken]] = await AsyncStorage.multiGet([
      STORAGE_KEYS.ACCESS_TOKEN,
      STORAGE_KEYS.REFRESH_TOKEN,
    ]);
    return { accessToken, refreshToken };
  },

  async clearTokens(): Promise<void> {
    await AsyncStorage.multiRemove([
      STORAGE_KEYS.ACCESS_TOKEN,
      STORAGE_KEYS.REFRESH_TOKEN,
      STORAGE_KEYS.USER_ID,
    ]);
  },
};
