import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, Text, View } from 'react-native';

// 스크린 임포트
import { HomeScreen } from '../screens/home/HomeScreen';
import { UserDetailScreen } from '../screens/home/UserDetailScreen';
import { SignalListScreen } from '../screens/signals/SignalListScreen';
import { SignalDetailScreen } from '../screens/signals/SignalDetailScreen';
import { ChatListScreen } from '../screens/chat/ChatListScreen';
import { ChatRoomScreen } from '../screens/chat/ChatRoomScreen';
import { PassportScreen } from '../screens/passport/PassportScreen';
import { CoinBalanceScreen } from '../screens/coins/CoinBalanceScreen';
import { CoinPurchaseScreen } from '../screens/coins/CoinPurchaseScreen';
import { MomentCheckinScreen } from '../screens/moments/MomentCheckinScreen';
import { MomentReviewScreen } from '../screens/moments/MomentReviewScreen';
import { GenderScreen } from '../screens/onboarding/GenderScreen';
import { ProfileScreen } from '../screens/onboarding/ProfileScreen';
import { PhotoScreen } from '../screens/onboarding/PhotoScreen';

import { colors } from '../constants/colors';
import { useChatStore } from '../store/chat.store';
import { useSignalStore } from '../store/signal.store';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

export type TabParamList = {
  Home: undefined;
  Signals: undefined;
  Chat: undefined;
  Passport: undefined;
};

export type AppStackParamList = {
  MainTabs: undefined;
  UserDetail: { userId: string };
  SignalDetail: { signalId: string };
  ChatRoom: { roomId: string; partnerName: string };
  MomentCheckin: { momentId: string; roomId: string };
  MomentReview: { momentId: string };
  CoinBalance: undefined;
  CoinPurchase: undefined;
  // 온보딩 (isNewUser)
  OnboardingGender: { userId: string };
  OnboardingProfile: { userId: string; gender: 'male' | 'female' | 'other' };
  OnboardingPhoto: { userId: string };
};

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<AppStackParamList>();

// ─── 탭 아이콘 (텍스트 폴백) ──────────────────────────────────────────────────

interface TabIconProps {
  label: string;
  badge?: number;
  focused: boolean;
}

const TabIcon: React.FC<TabIconProps> = ({ label, badge, focused }) => (
  <View style={styles.tabIconWrap}>
    <Text style={[styles.tabLabel, focused && styles.tabLabelFocused]}>
      {label}
    </Text>
    {!!badge && badge > 0 && (
      <View style={styles.badge}>
        <Text style={styles.badgeText}>{badge > 99 ? '99+' : badge}</Text>
      </View>
    )}
  </View>
);

// ─── 탭 네비게이터 ────────────────────────────────────────────────────────────

const MainTabs: React.FC = () => {
  const totalUnread = useChatStore((s) =>
    s.rooms.reduce((acc, r) => acc + r.unreadCount, 0),
  );
  const pendingSignals = useSignalStore((s) =>
    s.received.filter((sig) => sig.status === 'pending').length,
  );

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarShowLabel: false,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon label="홈" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Signals"
        component={SignalListScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon label="시그널" badge={pendingSignals} focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Chat"
        component={ChatListScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon label="채팅" badge={totalUnread} focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Passport"
        component={PassportScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon label="여권" focused={focused} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

// ─── 앱 스택 네비게이터 ───────────────────────────────────────────────────────

interface AppNavigatorProps {
  isOnboardingRequired: boolean;
}

export const AppNavigator: React.FC<AppNavigatorProps> = ({
  isOnboardingRequired,
}) => {
  return (
    <Stack.Navigator
      initialRouteName={
        isOnboardingRequired ? 'OnboardingGender' : 'MainTabs'
      }
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '700', fontSize: 16 },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.bg },
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen
        name="MainTabs"
        component={MainTabs}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="UserDetail"
        component={UserDetailScreen}
        options={{ title: '프로필', headerBackTitle: '' }}
      />
      <Stack.Screen
        name="SignalDetail"
        component={SignalDetailScreen}
        options={{ title: 'SIGNAL' }}
      />
      <Stack.Screen
        name="ChatRoom"
        component={ChatRoomScreen}
        options={({ route }) => ({
          title: route.params.partnerName,
          headerBackTitle: '',
        })}
      />
      <Stack.Screen
        name="MomentCheckin"
        component={MomentCheckinScreen}
        options={{ title: 'MOMENT 체크인', presentation: 'modal' }}
      />
      <Stack.Screen
        name="MomentReview"
        component={MomentReviewScreen}
        options={{ title: 'MOMENT 후기', presentation: 'modal' }}
      />
      <Stack.Screen
        name="CoinBalance"
        component={CoinBalanceScreen}
        options={{ title: '코인' }}
      />
      <Stack.Screen
        name="CoinPurchase"
        component={CoinPurchaseScreen}
        options={{ title: '코인 충전', presentation: 'modal' }}
      />
      {/* 온보딩 (isNewUser) */}
      <Stack.Screen
        name="OnboardingGender"
        component={GenderScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="OnboardingProfile"
        component={ProfileScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="OnboardingPhoto"
        component={PhotoScreen}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: 1,
    height: 70,
    paddingBottom: 12,
    paddingTop: 8,
  },
  tabIconWrap: { alignItems: 'center', justifyContent: 'center' },
  tabLabel: { fontSize: 12, color: colors.textFaint },
  tabLabelFocused: { color: colors.primary, fontWeight: '700' },
  badge: {
    position: 'absolute',
    top: -4,
    right: -10,
    backgroundColor: colors.accent,
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: { fontSize: 10, color: colors.white, fontWeight: '700' },
});
