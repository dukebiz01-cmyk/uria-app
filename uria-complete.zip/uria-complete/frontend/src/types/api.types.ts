// ✅ BUG4 수정: SignalStatus 백엔드와 일치

export interface ApiResponse<T> {
  data: T;
  message?: string;
}
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasNext: boolean;
}
export interface ApiError {
  code: string;
  message: string;
  status: number;
}
export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}
export interface AuthResponse extends AuthTokens {
  userId: string;
  isNewUser: boolean;
}
export type Gender = 'M' | 'F';
export type PassportTier = 'Starter' | 'Silver' | 'Gold' | 'Platinum';
export type RepLevel = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export interface UserProfile {
  id: string;
  nickname: string;
  birthYear: number;
  age: number;
  gender: Gender;
  bio: string;
  photos: string[];
  selfieVerified: boolean;
  isTonightMode: boolean;
  distanceM?: number;
  passportTier: PassportTier;
  trustScore: number;
  coinBalance: number;
  pointBalance: number;
}

// ✅ BUG4 핵심 수정: 'declined' → 'rejected', 'hold' → 'held', 'cancelled' 추가
export type SignalStatus =
  | 'pending'
  | 'accepted'
  | 'rejected'
  | 'held'
  | 'expired'
  | 'cancelled';

export const SIGNAL_STATUS_LABEL: Record<SignalStatus, string> = {
  pending:   '대기 중',
  accepted:  '수락됨',
  rejected:  '거절됨',
  held:      '보류',
  expired:   '만료됨',
  cancelled: '취소됨',
};

export interface Signal {
  id: string;
  senderId: string;
  receiverId: string;
  senderNickname: string;
  message?: string;
  status: SignalStatus;
  escrowCoin: number;
  expiresAt: string;
  createdAt: string;
  chatRoomId?: string;
}

export type MomentStatus = 'pending' | 'checked_in' | 'verified' | 'rejected' | 'expired';

export interface Moment {
  id: string;
  signalId: string;
  maleId: string;
  femaleId: string;
  status: MomentStatus;
  verifiedAt?: string;
  createdAt: string;
}

export interface ChatRoom {
  id: string;
  signalId: string;
  otherUser: Pick<UserProfile, 'id' | 'nickname' | 'photos'>;
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: number;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  message: string;
  isSystem: boolean;
  createdAt: string;
}

export interface PassportMetrics {
  trustScore: number;
  tier: PassportTier;
  responseRate: number;
  promiseRate: number;
  momentVerifiedCount: number;
  validReportCount: number;
}

export interface ReputationMetrics {
  repScore: number;
  level: RepLevel;
  momentVerifiedCount: number;
  noShowRate: number;
}

export interface WalletBalance {
  coinBalance: number;
  pointBalance: number;
}

// WebSocket 이벤트 타입
export type WsEventType =
  | 'message'
  | 'read'
  | 'ping'
  | 'pong'
  | 'connected'
  | 'error'
  | 'signal_received'
  | 'signal_updated';

export interface WsEvent {
  type: WsEventType;
  data?: unknown;
}
