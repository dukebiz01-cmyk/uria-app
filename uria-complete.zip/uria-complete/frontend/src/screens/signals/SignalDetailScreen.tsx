import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { signalsApi } from '../../api/signals.api';
import { useSignalStore } from '../../store/signal.store';
import { Avatar } from '../../components/common/Avatar';
import { SignalStatusBadge, TierBadge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import {
  formatDate,
  formatSignalCountdown,
} from '../../utils/format';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { Signal } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'SignalDetail'>;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const SignalDetailScreen: React.FC<Props> = ({ route, navigation }) => {
  const { signalId } = route.params;

  const respondSignal = useSignalStore((s) => s.respondSignal);

  const [signal, setSignal] = useState<Signal | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [countdown, setCountdown] = useState('');
  const [isResponding, setIsResponding] = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const result = await signalsApi.getSignal(signalId);
        setSignal(result);
        setCountdown(formatSignalCountdown(result.expiresAt));
      } catch (e) {
        const err = parseApiError(e);
        Alert.alert('오류', getErrorMessage(err));
        navigation.goBack();
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [signalId, navigation]);

  useEffect(() => {
    if (!signal || signal.status !== 'pending') return;

    timerRef.current = setInterval(() => {
      setCountdown(formatSignalCountdown(signal.expiresAt));
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [signal]);

  const handleRespond = async (action: 'accept' | 'decline' | 'hold') => {
    if (!signal) return;
    setIsResponding(true);

    try {
      await respondSignal(signal.id, action);
      const actionLabel = { accept: '수락', decline: '거절', hold: '보류' }[action];
      Alert.alert(`SIGNAL ${actionLabel}`, `처리가 완료되었습니다.`, [
        { text: '확인', onPress: () => navigation.goBack() },
      ]);
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('오류', getErrorMessage(err));
    } finally {
      setIsResponding(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  if (!signal) return null;

  const peer = signal.fromUser; // 이 화면은 받은 SIGNAL 기준
  const isPending = signal.status === 'pending';

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* 상태 배너 */}
        <View style={styles.statusBanner}>
          <SignalStatusBadge status={signal.status} size="md" />
          {isPending && (
            <Text style={styles.countdown}>⏱ {countdown}</Text>
          )}
        </View>

        {/* 보낸 사람 정보 */}
        <View style={styles.userCard}>
          <Avatar uri={peer.photos[0]} nickname={peer.nickname} size="xl" />
          <View style={styles.userInfo}>
            <Text style={styles.peerName}>{peer.nickname}</Text>
            <Text style={styles.peerAge}>{peer.age}세</Text>
            <TierBadge tier={peer.passportTier} size="md" />
          </View>
        </View>

        {/* 시그널 메시지 */}
        {signal.message ? (
          <View style={styles.messageBox}>
            <Text style={styles.messageLabel}>보낸 메시지</Text>
            <Text style={styles.messageText}>"{signal.message}"</Text>
          </View>
        ) : null}

        {/* 날짜 정보 */}
        <View style={styles.metaBox}>
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>시그널 유형</Text>
            <Text style={styles.metaValue}>
              {signal.type === 'premium' ? '💎 프리미엄' : '⚡ 기본'}
            </Text>
          </View>
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>수신 시각</Text>
            <Text style={styles.metaValue}>
              {formatDate(signal.createdAt, 'YYYY.MM.DD HH:mm')}
            </Text>
          </View>
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>만료 시각</Text>
            <Text style={styles.metaValue}>
              {formatDate(signal.expiresAt, 'YYYY.MM.DD HH:mm')}
            </Text>
          </View>
        </View>

        {/* 액션 버튼 (대기 중인 받은 시그널만) */}
        {isPending && (
          <View style={styles.actions}>
            <Button
              title="💚 수락"
              onPress={() => handleRespond('accept')}
              isLoading={isResponding}
              fullWidth
              size="lg"
            />
            <Button
              title="⏳ 보류"
              variant="outline"
              onPress={() => handleRespond('hold')}
              isLoading={isResponding}
              fullWidth
            />
            <Button
              title="거절"
              variant="ghost"
              onPress={() =>
                Alert.alert(
                  '거절 확인',
                  `${peer.nickname}님의 SIGNAL을 거절하시겠습니까?`,
                  [
                    { text: '취소', style: 'cancel' },
                    {
                      text: '거절',
                      style: 'destructive',
                      onPress: () => handleRespond('decline'),
                    },
                  ],
                )
              }
              fullWidth
            />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, gap: 20, flexGrow: 1 },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 14,
  },
  countdown: { fontSize: 15, color: colors.accent, fontWeight: '700' },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    padding: 20,
    backgroundColor: colors.surface,
    borderRadius: 20,
  },
  userInfo: { gap: 6 },
  peerName: { fontSize: 22, fontWeight: '800', color: colors.text },
  peerAge: { fontSize: 15, color: colors.textMuted },
  messageBox: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 8,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  messageLabel: { fontSize: 12, color: colors.textFaint, fontWeight: '600' },
  messageText: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  metaBox: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaLabel: { fontSize: 13, color: colors.textMuted },
  metaValue: { fontSize: 13, color: colors.text, fontWeight: '600' },
  actions: { gap: 10, marginTop: 'auto' },
});
