import { AxiosError } from 'axios';
import { ApiError } from '../types/api.types';

// ─── API 에러 파싱 ─────────────────────────────────────────────────────────────

export function parseApiError(error: unknown): ApiError {
  if (error instanceof AxiosError) {
    const data = error.response?.data as Record<string, unknown> | undefined;

    // 서버가 표준 에러 형식 { code, message } 을 반환하는 경우
    if (data && typeof data.message === 'string') {
      return {
        code: typeof data.code === 'string' ? data.code : 'API_ERROR',
        message: data.message,
        status: error.response?.status ?? 0,
      };
    }

    // HTTP 상태별 기본 메시지
    const status = error.response?.status ?? 0;
    return {
      code: `HTTP_${status}`,
      message: getHttpErrorMessage(status),
      status,
    };
  }

  if (error instanceof Error) {
    return {
      code: 'UNKNOWN_ERROR',
      message: error.message || '알 수 없는 오류가 발생했습니다.',
      status: 0,
    };
  }

  return {
    code: 'UNKNOWN_ERROR',
    message: '알 수 없는 오류가 발생했습니다.',
    status: 0,
  };
}

function getHttpErrorMessage(status: number): string {
  switch (status) {
    case 400:
      return '잘못된 요청입니다.';
    case 401:
      return '인증이 필요합니다. 다시 로그인해주세요.';
    case 403:
      return '접근 권한이 없습니다.';
    case 404:
      return '요청한 리소스를 찾을 수 없습니다.';
    case 409:
      return '이미 존재하는 데이터입니다.';
    case 422:
      return '입력값을 확인해주세요.';
    case 429:
      return '요청이 너무 많습니다. 잠시 후 다시 시도해주세요.';
    case 500:
      return '서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.';
    case 502:
    case 503:
      return '서비스가 일시적으로 중단되었습니다. 잠시 후 다시 시도해주세요.';
    case 0:
      return '네트워크 연결을 확인해주세요.';
    default:
      return `오류가 발생했습니다. (${status})`;
  }
}

// ─── 에러 코드별 사용자 메시지 ────────────────────────────────────────────────

const ERROR_MESSAGES: Record<string, string> = {
  INSUFFICIENT_COINS: '코인이 부족합니다. 코인을 충전해주세요.',
  SIGNAL_ALREADY_SENT: '이미 시그널을 보낸 상대입니다.',
  SIGNAL_EXPIRED: '만료된 시그널입니다.',
  MOMENT_IN_PROGRESS: '이미 진행 중인 MOMENT가 있습니다.',
  LOCATION_TOO_FAR: '상대방과 거리가 너무 멀어 체크인할 수 없습니다.',
  TONIGHT_MODE_REQUIRED: 'TONIGHT MODE를 활성화해야 사용할 수 있습니다.',
  PHONE_ALREADY_REGISTERED: '이미 가입된 전화번호입니다.',
  OTP_INVALID: '인증번호가 올바르지 않습니다.',
  OTP_EXPIRED: '인증번호가 만료되었습니다. 다시 요청해주세요.',
  USER_NOT_FOUND: '사용자를 찾을 수 없습니다.',
  PAYMENT_FAILED: '결제에 실패했습니다. 다시 시도해주세요.',
  PAYMENT_VERIFY_FAILED: '결제 검증에 실패했습니다. 고객센터에 문의해주세요.',
};

export function getErrorMessage(error: ApiError): string {
  return ERROR_MESSAGES[error.code] ?? error.message;
}

// ─── 네트워크 오류 감지 ───────────────────────────────────────────────────────

export function isNetworkError(error: unknown): boolean {
  if (error instanceof AxiosError) {
    return !error.response && error.code !== 'ECONNABORTED';
  }
  return false;
}

export function isAuthError(error: ApiError): boolean {
  return error.status === 401;
}
