import apiClient from './client';
import {
  ApiResponse,
  Moment,
  MomentCheckinBody,
  MomentReview,
} from '../types/api.types';

export const momentsApi = {
  /**
   * MOMENT 요청 전송
   */
  requestMoment: async (roomId: string): Promise<Moment> => {
    const { data } = await apiClient.post<ApiResponse<Moment>>(
      `/moments/request`,
      { roomId },
    );
    return data.data;
  },

  /**
   * MOMENT 수락/거절
   */
  respondMoment: async (
    momentId: string,
    action: 'accept' | 'decline',
  ): Promise<Moment> => {
    const { data } = await apiClient.patch<ApiResponse<Moment>>(
      `/moments/${momentId}/respond`,
      { action },
    );
    return data.data;
  },

  /**
   * MOMENT 상세 조회
   */
  getMoment: async (momentId: string): Promise<Moment> => {
    const { data } = await apiClient.get<ApiResponse<Moment>>(
      `/moments/${momentId}`,
    );
    return data.data;
  },

  /**
   * 현재 방의 진행 중인 MOMENT 조회
   */
  getActiveMoment: async (roomId: string): Promise<Moment | null> => {
    try {
      const { data } = await apiClient.get<ApiResponse<Moment>>(
        `/moments/active`,
        { params: { roomId } },
      );
      return data.data;
    } catch {
      return null;
    }
  },

  /**
   * GPS 체크인
   */
  checkin: async (
    momentId: string,
    body: MomentCheckinBody,
  ): Promise<Moment> => {
    const { data } = await apiClient.post<ApiResponse<Moment>>(
      `/moments/${momentId}/checkin`,
      body,
    );
    return data.data;
  },

  /**
   * MOMENT 완료 후 리뷰 작성
   */
  submitReview: async (review: MomentReview): Promise<void> => {
    await apiClient.post<ApiResponse<void>>('/moments/review', review);
  },

  /**
   * MOMENT 취소
   */
  cancelMoment: async (momentId: string): Promise<void> => {
    await apiClient.delete<ApiResponse<void>>(`/moments/${momentId}`);
  },
};
