import React, { useEffect } from 'react';
import {
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList, TabParamList } from '../../navigation/AppNavigator';
import { useUserStore } from '../../store/user.store';
import { Avatar } from '../../components/common/Avatar';
import { TierBadgeLarge } from '../../components/passport/TierBadge';
import { TrustScoreBar } from '../../components/passport/TrustScoreBar';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { formatPercent, formatCoin } from '../../utils/format';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, 'Passport'>,
  NativeStackScreenProps<AppStackParamList>
>;

// ─── 지표 카드 ────────────────────────────────────────────────────────────────

interface StatCardProps {
  label: string;
  value: string;
  description?: string;
  accent?: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, description, accent }) => (
  <View style={styles.statCard}>
    <Text style={[styles.statValue, accent ? { color: accent } : undefined]}>
      {value}
    </Text>
    <Text style={styles.statLabel}>{label}</Text>
    {description && <Text style={styles.statDesc}>{description}</Text>}
  </View>
);

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const PassportScreen: React.FC<Props> = ({ navigation }) => {
  const profile = useUserStore((s) => s.profile);
  const passport = useUserStore((s) => s.passport);
  const isLoading = useUserStore((s) => s.isLoading);
  const fetchProfile = useUserStore((s) => s.fetchProfile);
  const fetchPassport = useUserStore((s) => s.fetchPassport);

  const [isRefreshing, setIsRefreshing] = React.useState(false);

  useEffect(() => {
    if (!passport) fetchPassport();
  }, [passport, fetchPassport]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([fetchProfile(), fetchPassport()]);
    setIsRefreshing(false);
  };

  if (isLoading && !profile) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  if (!profile || !passport) return null;

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* 상단 — 프로필 */}
        <View style={styles.profileSection}>
          <Avatar
            uri={profile.photos[0]}
            nickname={profile.nickname}
            size="xl"
          />
          <Text style={styles.nickname}>{profile.nickname}</Text>
          <TierBadgeLarge tier={passport.tier} large />
        </View>

        {/* Trust Score 바 */}
        <View style={styles.card}>
          <TrustScoreBar score={passport.trustScore} tier={passport.tier} />
        </View>

        {/* 핵심 지표 그리드 */}
        <View style={styles.statsGrid}>
          <StatCard
            label="응답률"
            value={formatPercent(passport.responseRate)}
            description="받은 메시지 응답 비율"
            accent={passport.responseRate >= 80 ? colors.green : undefined}
          />
          <StatCard
            label="약속이행률"
            value={formatPercent(passport.punctualityRate)}
            description="MOMENT 완료 비율"
            accent={passport.punctualityRate >= 80 ? colors.teal : undefined}
          />
          <StatCard
            label="MOMENT 완료"
            value={`${passport.momentCount}회`}
            description="실제 만남 횟수"
            accent={colors.gold}
          />
          <StatCard
            label="시그널 수락률"
            value={formatPercent(passport.signalAcceptRate)}
            description="받은 SIGNAL 수락 비율"
          />
        </View>

        {/* 활동 요약 */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>활동 요약</Text>
          <View style={styles.activityRow}>
            <View style={styles.activityItem}>
              <Text style={styles.activityValue}>{passport.signalsSent}</Text>
              <Text style={styles.activityLabel}>보낸 SIGNAL</Text>
            </View>
            <View style={styles.activityDivider} />
            <View style={styles.activityItem}>
              <Text style={styles.activityValue}>{passport.signalsReceived}</Text>
              <Text style={styles.activityLabel}>받은 SIGNAL</Text>
            </View>
            <View style={styles.activityDivider} />
            <View style={styles.activityItem}>
              <Text style={styles.activityValue}>{formatCoin(profile.coinBalance)}</Text>
              <Text style={styles.activityLabel}>보유 코인</Text>
            </View>
          </View>
        </View>

        {/* 코인 충전 버튼 */}
        <TouchableOpacity
          style={styles.coinButton}
          onPress={() => (navigation as any).navigate('CoinPurchase')}
        >
          <Text style={styles.coinButtonText}>💰 코인 충전</Text>
        </TouchableOpacity>

        {/* 티어 안내 */}
        <View style={styles.tierGuide}>
          <Text style={styles.tierGuideTitle}>TIER 안내</Text>
          {[
            { tier: 'Starter', req: 'Trust Score 0~49', emoji: '🌱' },
            { tier: 'Silver', req: 'Trust Score 50~69', emoji: '🥈' },
            { tier: 'Gold', req: 'Trust Score 70~89', emoji: '🥇' },
            { tier: 'Platinum', req: 'Trust Score 90+', emoji: '💎' },
          ].map((t) => (
            <View
              key={t.tier}
              style={[
                styles.tierRow,
                t.tier === passport.tier && styles.tierRowActive,
              ]}
            >
              <Text style={styles.tierEmoji}>{t.emoji}</Text>
              <View>
                <Text style={styles.tierName}>{t.tier}</Text>
                <Text style={styles.tierReq}>{t.req}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, gap: 16, paddingBottom: 40 },

  profileSection: {
    alignItems: 'center',
    gap: 12,
    paddingVertical: 20,
  },
  nickname: { fontSize: 22, fontWeight: '800', color: colors.text },

  card: {
    backgroundColor: colors.surface,
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 16,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textMuted,
    letterSpacing: 0.5,
  },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 4,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  statValue: { fontSize: 22, fontWeight: '800', color: colors.text },
  statLabel: { fontSize: 12, color: colors.textMuted, fontWeight: '600' },
  statDesc: { fontSize: 10, color: colors.textFaint, textAlign: 'center' },

  activityRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  activityItem: { alignItems: 'center', gap: 4 },
  activityValue: { fontSize: 20, fontWeight: '800', color: colors.text },
  activityLabel: { fontSize: 11, color: colors.textFaint },
  activityDivider: { width: 1, height: 40, backgroundColor: colors.border },

  coinButton: {
    backgroundColor: colors.goldAlpha10,
    borderRadius: 16,
    padding: 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.gold,
  },
  coinButtonText: { fontSize: 16, fontWeight: '700', color: colors.gold },

  tierGuide: {
    backgroundColor: colors.surface,
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
  },
  tierGuideTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textMuted,
  },
  tierRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 10,
    borderRadius: 12,
  },
  tierRowActive: { backgroundColor: colors.primaryAlpha10 },
  tierEmoji: { fontSize: 22 },
  tierName: { fontSize: 14, fontWeight: '700', color: colors.text },
  tierReq: { fontSize: 12, color: colors.textFaint },
});
