import React, { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { usersApi } from '../../api/users.api';
import { useUserStore } from '../../store/user.store';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { colors } from '../../constants/colors';
import { getErrorMessage, parseApiError } from '../../utils/errors';
import { calcAge } from '../../utils/format';

// ─── 스키마 ───────────────────────────────────────────────────────────────────

const schema = z.object({
  nickname: z
    .string()
    .min(2, '닉네임은 2자 이상이어야 합니다.')
    .max(12, '닉네임은 12자 이하여야 합니다.')
    .regex(/^[가-힣a-zA-Z0-9_]+$/, '닉네임에 특수문자를 사용할 수 없습니다.'),
  birthDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'YYYY-MM-DD 형식으로 입력해주세요.')
    .refine((date) => {
      const age = calcAge(date);
      return age >= 19 && age <= 60;
    }, '만 19세 이상 60세 이하만 가입할 수 있습니다.'),
  bio: z
    .string()
    .max(150, '소개는 150자 이하여야 합니다.')
    .optional(),
});

type FormData = z.infer<typeof schema>;

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AuthStackParamList, 'Profile'>;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const ProfileScreen: React.FC<Props> = ({ navigation, route }) => {
  const { userId, gender } = route.params;
  const updateProfile = useUserStore((s) => s.updateProfile);
  const [isLoading, setIsLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { nickname: '', birthDate: '', bio: '' },
  });

  const onSubmit = async (data: FormData) => {
    setIsLoading(true);
    try {
      const updated = await usersApi.updateMe({
        nickname: data.nickname,
        birthDate: data.birthDate,
        gender,
        bio: data.bio,
      });
      updateProfile(updated);
      navigation.navigate('Photo', { userId });
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('오류', getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <Text style={styles.step}>2 / 3</Text>
            <Text style={styles.title}>프로필 설정</Text>
            <Text style={styles.subtitle}>
              다른 유저에게 보여질 정보입니다.
            </Text>
          </View>

          <View style={styles.form}>
            <Controller
              control={control}
              name="nickname"
              render={({ field: { onChange, value, onBlur } }) => (
                <Input
                  label="닉네임"
                  placeholder="사용할 닉네임을 입력하세요"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.nickname?.message}
                  maxLength={12}
                  hint="2~12자, 한글·영문·숫자·_ 사용 가능"
                />
              )}
            />

            <Controller
              control={control}
              name="birthDate"
              render={({ field: { onChange, value, onBlur } }) => (
                <Input
                  label="생년월일"
                  placeholder="1995-05-15"
                  keyboardType="numeric"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.birthDate?.message}
                  maxLength={10}
                  hint="YYYY-MM-DD 형식으로 입력 (만 19세 이상)"
                />
              )}
            />

            <Controller
              control={control}
              name="bio"
              render={({ field: { onChange, value, onBlur } }) => (
                <Input
                  label="자기소개 (선택)"
                  placeholder="간단한 소개를 작성해주세요"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.bio?.message}
                  multiline
                  numberOfLines={3}
                  maxLength={150}
                />
              )}
            />
          </View>

          <Button
            title="다음"
            onPress={handleSubmit(onSubmit)}
            isLoading={isLoading}
            fullWidth
            size="lg"
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  content: {
    padding: 24,
    gap: 32,
    flexGrow: 1,
    justifyContent: 'center',
  },
  header: { gap: 10 },
  step: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  title: { fontSize: 26, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 14, color: colors.textMuted, lineHeight: 21 },
  form: { gap: 20 },
});
