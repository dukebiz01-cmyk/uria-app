import apiClient from './client';
import { ApiResponse, AuthResponse, OtpVerifyBody, PhoneRequestBody } from '../types/api.types';

export const authApi = {
  /**
   * 전화번호로 OTP 발송 요청
   */
  requestOtp: async (body: PhoneRequestBody): Promise<void> => {
    await apiClient.post<ApiResponse<void>>('/auth/otp/request', body);
  },

  /**
   * OTP 검증 및 로그인/가입
   */
  verifyOtp: async (body: OtpVerifyBody): Promise<AuthResponse> => {
    const { data } = await apiClient.post<ApiResponse<AuthResponse>>(
      '/auth/otp/verify',
      body,
    );
    return data.data;
  },

  /**
   * 액세스 토큰 갱신 (client.ts 인터셉터에서 직접 호출하지만, 명시적 갱신에도 사용)
   */
  refreshToken: async (refreshToken: string): Promise<AuthResponse> => {
    const { data } = await apiClient.post<ApiResponse<AuthResponse>>(
      '/auth/refresh',
      { refreshToken },
    );
    return data.data;
  },

  /**
   * 로그아웃 (서버 측 토큰 무효화)
   */
  logout: async (refreshToken: string): Promise<void> => {
    await apiClient.post<ApiResponse<void>>('/auth/logout', { refreshToken });
  },

  /**
   * 회원 탈퇴
   */
  withdraw: async (reason?: string): Promise<void> => {
    await apiClient.delete<ApiResponse<void>>('/auth/account', {
      data: { reason },
    });
  },
};
