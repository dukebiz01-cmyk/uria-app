import apiClient from './client';
import {
  ApiResponse,
  NearbyUsersParams,
  PaginatedResponse,
  UpdateProfileBody,
  UserProfile,
} from '../types/api.types';

export const usersApi = {
  /**
   * 내 프로필 조회
   */
  getMe: async (): Promise<UserProfile> => {
    const { data } = await apiClient.get<ApiResponse<UserProfile>>('/users/me');
    return data.data;
  },

  /**
   * 내 프로필 수정
   */
  updateMe: async (body: UpdateProfileBody): Promise<UserProfile> => {
    const { data } = await apiClient.patch<ApiResponse<UserProfile>>(
      '/users/me',
      body,
    );
    return data.data;
  },

  /**
   * 사진 업로드 (multipart)
   */
  uploadPhoto: async (formData: FormData): Promise<{ url: string }> => {
    const { data } = await apiClient.post<ApiResponse<{ url: string }>>(
      '/users/me/photos',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },

  /**
   * 사진 삭제
   */
  deletePhoto: async (photoUrl: string): Promise<void> => {
    await apiClient.delete<ApiResponse<void>>('/users/me/photos', {
      data: { url: photoUrl },
    });
  },

  /**
   * 특정 사용자 프로필 조회
   */
  getUserProfile: async (userId: string): Promise<UserProfile> => {
    const { data } = await apiClient.get<ApiResponse<UserProfile>>(
      `/users/${userId}`,
    );
    return data.data;
  },

  /**
   * 주변 유저 목록 (TONIGHT MODE)
   */
  getNearbyUsers: async (
    params: NearbyUsersParams,
  ): Promise<PaginatedResponse<UserProfile>> => {
    const { data } = await apiClient.get<ApiResponse<PaginatedResponse<UserProfile>>>(
      '/users/nearby',
      { params },
    );
    return data.data;
  },

  /**
   * TONIGHT MODE 활성화/비활성화
   */
  setTonightMode: async (active: boolean): Promise<UserProfile> => {
    const { data } = await apiClient.post<ApiResponse<UserProfile>>(
      '/users/me/tonight-mode',
      { active },
    );
    return data.data;
  },

  /**
   * 차단하기
   */
  blockUser: async (userId: string): Promise<void> => {
    await apiClient.post<ApiResponse<void>>(`/users/${userId}/block`);
  },

  /**
   * 신고하기
   */
  reportUser: async (
    userId: string,
    reason: string,
    details?: string,
  ): Promise<void> => {
    await apiClient.post<ApiResponse<void>>(`/users/${userId}/report`, {
      reason,
      details,
    });
  },
};
