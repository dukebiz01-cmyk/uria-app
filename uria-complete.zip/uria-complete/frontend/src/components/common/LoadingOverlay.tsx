import React from 'react';
import {
  ActivityIndicator,
  Modal,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { colors } from '../../constants/colors';

// ─── LoadingOverlay ────────────────────────────────────────────────────────────

interface LoadingOverlayProps {
  visible: boolean;
  message?: string;
}

export const LoadingOverlay: React.FC<LoadingOverlayProps> = ({
  visible,
  message,
}) => {
  return (
    <Modal transparent visible={visible} animationType="fade" statusBarTranslucent>
      <View style={styles.backdrop}>
        <View style={styles.card}>
          <ActivityIndicator size="large" color={colors.primary} />
          {message && <Text style={styles.message}>{message}</Text>}
        </View>
      </View>
    </Modal>
  );
};

// ─── 인라인 스피너 ─────────────────────────────────────────────────────────────

interface SpinnerProps {
  color?: string;
  size?: 'small' | 'large';
}

export const Spinner: React.FC<SpinnerProps> = ({
  color = colors.primary,
  size = 'large',
}) => (
  <View style={styles.spinnerContainer}>
    <ActivityIndicator size={size} color={color} />
  </View>
);

// ─── 스켈레톤 (사각형 블록) ────────────────────────────────────────────────────

interface SkeletonProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: object;
}

export const Skeleton: React.FC<SkeletonProps> = ({
  width = '100%',
  height = 16,
  borderRadius = 8,
  style,
}) => (
  <View
    style={[
      {
        width: width as number,
        height,
        borderRadius,
        backgroundColor: colors.surfaceAlt,
      },
      style,
    ]}
  />
);

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: colors.overlay,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 28,
    alignItems: 'center',
    gap: 12,
    minWidth: 120,
  },
  message: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
  },
  spinnerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
