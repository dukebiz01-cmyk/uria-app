import apiClient from './client';
import {
  ApiResponse,
  PaginatedResponse,
  RespondSignalBody,
  SendSignalBody,
  Signal,
} from '../types/api.types';

export const signalsApi = {
  /**
   * SIGNAL 전송
   */
  sendSignal: async (body: SendSignalBody): Promise<Signal> => {
    const { data } = await apiClient.post<ApiResponse<Signal>>(
      '/signals',
      body,
    );
    return data.data;
  },

  /**
   * 받은 SIGNAL 목록
   */
  getReceivedSignals: async (
    page = 1,
    pageSize = 20,
  ): Promise<PaginatedResponse<Signal>> => {
    const { data } = await apiClient.get<ApiResponse<PaginatedResponse<Signal>>>(
      '/signals/received',
      { params: { page, pageSize } },
    );
    return data.data;
  },

  /**
   * 보낸 SIGNAL 목록
   */
  getSentSignals: async (
    page = 1,
    pageSize = 20,
  ): Promise<PaginatedResponse<Signal>> => {
    const { data } = await apiClient.get<ApiResponse<PaginatedResponse<Signal>>>(
      '/signals/sent',
      { params: { page, pageSize } },
    );
    return data.data;
  },

  /**
   * SIGNAL 상세 조회
   */
  getSignal: async (signalId: string): Promise<Signal> => {
    const { data } = await apiClient.get<ApiResponse<Signal>>(
      `/signals/${signalId}`,
    );
    return data.data;
  },

  /**
   * SIGNAL 응답 (수락/거절/hold)
   */
  respondSignal: async (
    signalId: string,
    body: RespondSignalBody,
  ): Promise<Signal> => {
    const { data } = await apiClient.patch<ApiResponse<Signal>>(
      `/signals/${signalId}/respond`,
      body,
    );
    return data.data;
  },
};
