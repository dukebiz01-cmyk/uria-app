/**
 * URIA App Entry
 * React Native 0.74+ / Bare Workflow
 */

import React, { useEffect } from 'react';
import { BackHandler, StatusBar, ToastAndroid, Platform } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { RootNavigator } from './src/navigation/RootNavigator';
import { ErrorBoundary } from './src/components/common/ErrorBoundary';
import { useWebSocket } from './src/hooks/useWebSocket';
import { usePushNotification } from './src/hooks/usePushNotification';
import { colors } from './src/constants/colors';

// ─── 앱 내부 프로바이더 ───────────────────────────────────────────────────────

const AppInner: React.FC = () => {
  // WebSocket 전역 연결
  useWebSocket();

  // 푸시 알림 설정
  usePushNotification();

  return <RootNavigator />;
};

// ─── 루트 컴포넌트 ────────────────────────────────────────────────────────────

const App: React.FC = () => {
  // Android 뒤로가기 하드웨어 버튼 — 네비게이션이 없으면 앱 종료
  // (React Navigation이 자체 처리하지만, 최상위 fallback)

  return (
    <ErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <StatusBar
            barStyle="light-content"
            backgroundColor={colors.bg}
            translucent={false}
          />
          <AppInner />
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </ErrorBoundary>
  );
};

export default App;
