import apiClient from './client';
import {
  ApiResponse,
  ChatMessage,
  ChatRoom,
  PaginatedResponse,
  SendMessageBody,
} from '../types/api.types';

export const chatApi = {
  /**
   * 채팅방 목록
   */
  getRooms: async (
    page = 1,
    pageSize = 20,
  ): Promise<PaginatedResponse<ChatRoom>> => {
    const { data } = await apiClient.get<ApiResponse<PaginatedResponse<ChatRoom>>>(
      '/chat/rooms',
      { params: { page, pageSize } },
    );
    return data.data;
  },

  /**
   * 채팅방 상세 (메시지 이력)
   */
  getMessages: async (
    roomId: string,
    before?: string, // cursor (messageId)
    limit = 50,
  ): Promise<PaginatedResponse<ChatMessage>> => {
    const { data } = await apiClient.get<ApiResponse<PaginatedResponse<ChatMessage>>>(
      `/chat/rooms/${roomId}/messages`,
      { params: { before, limit } },
    );
    return data.data;
  },

  /**
   * 메시지 전송
   */
  sendMessage: async (
    roomId: string,
    body: SendMessageBody,
  ): Promise<ChatMessage> => {
    const { data } = await apiClient.post<ApiResponse<ChatMessage>>(
      `/chat/rooms/${roomId}/messages`,
      body,
    );
    return data.data;
  },

  /**
   * 메시지 읽음 처리
   */
  markAsRead: async (roomId: string, lastMessageId: string): Promise<void> => {
    await apiClient.post<ApiResponse<void>>(
      `/chat/rooms/${roomId}/read`,
      { lastMessageId },
    );
  },

  /**
   * 채팅방 나가기
   */
  leaveRoom: async (roomId: string): Promise<void> => {
    await apiClient.delete<ApiResponse<void>>(`/chat/rooms/${roomId}`);
  },

  /**
   * 이미지 메시지 업로드
   */
  uploadImage: async (roomId: string, formData: FormData): Promise<{ url: string }> => {
    const { data } = await apiClient.post<ApiResponse<{ url: string }>>(
      `/chat/rooms/${roomId}/images`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },
};
