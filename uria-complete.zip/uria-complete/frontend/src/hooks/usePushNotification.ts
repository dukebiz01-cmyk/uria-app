import { useEffect, useRef, useState } from 'react';
import { Platform } from 'react-native';
import messaging, {
  FirebaseMessagingTypes,
} from '@react-native-firebase/messaging';
import { useNavigation } from '@react-navigation/native';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface UsePushNotificationReturn {
  fcmToken: string | null;
  isPermissionGranted: boolean;
  requestPermission: () => Promise<boolean>;
}

// ─── 알림 데이터 파싱 ─────────────────────────────────────────────────────────

function parseNotificationData(
  data: Record<string, string> | undefined,
): { screen: string; params: Record<string, string> } | null {
  if (!data?.screen) return null;
  return { screen: data.screen, params: data };
}

// ─── 훅 ──────────────────────────────────────────────────────────────────────

export function usePushNotification(): UsePushNotificationReturn {
  const [fcmToken, setFcmToken] = useState<string | null>(null);
  const [isPermissionGranted, setIsPermissionGranted] = useState(false);
  const navigation = useNavigation();
  const unsubscribeRef = useRef<(() => void)[]>([]);

  const requestPermission = async (): Promise<boolean> => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    setIsPermissionGranted(enabled);
    return enabled;
  };

  // FCM 토큰 등록 및 갱신
  useEffect(() => {
    const registerToken = async () => {
      try {
        if (Platform.OS === 'ios') {
          await messaging().registerDeviceForRemoteMessages();
        }

        const token = await messaging().getToken();
        setFcmToken(token);

        // TODO: 서버에 토큰 등록 → usersApi.registerFcmToken(token)
      } catch {
        // 권한 없을 때 무시
      }
    };

    requestPermission().then((granted) => {
      if (granted) registerToken();
    });

    // 토큰 갱신 리스너
    const tokenRefreshUnsub = messaging().onTokenRefresh((newToken) => {
      setFcmToken(newToken);
      // TODO: 서버에 새 토큰 등록
    });

    unsubscribeRef.current.push(tokenRefreshUnsub);

    return () => {
      unsubscribeRef.current.forEach((unsub) => unsub());
      unsubscribeRef.current = [];
    };
  }, []);

  // 포그라운드 알림 처리
  useEffect(() => {
    const foregroundUnsub = messaging().onMessage(
      async (remoteMessage: FirebaseMessagingTypes.RemoteMessage) => {
        const { notification, data } = remoteMessage;
        if (!notification) return;

        // RN에서 로컬 알림 표시 (react-native-push-notification 또는 직접 구현 필요)
        // 여기서는 in-app 처리만 수행
        console.log('[FCM] Foreground message:', notification.title);
      },
    );

    unsubscribeRef.current.push(foregroundUnsub);

    return () => {
      foregroundUnsub();
    };
  }, []);

  // 백그라운드/종료 상태에서 알림 탭 → 앱 열릴 때 딥링크
  useEffect(() => {
    // 앱이 완전히 종료된 상태에서 알림 탭
    messaging()
      .getInitialNotification()
      .then((remoteMessage) => {
        if (!remoteMessage?.data) return;
        const nav = parseNotificationData(
          remoteMessage.data as Record<string, string>,
        );
        if (nav) {
          // navigation이 준비된 후 이동
          setTimeout(() => {
            (navigation as any).navigate(nav.screen, nav.params);
          }, 500);
        }
      });

    // 앱이 백그라운드에서 알림 탭
    const bgUnsub = messaging().onNotificationOpenedApp((remoteMessage) => {
      if (!remoteMessage?.data) return;
      const nav = parseNotificationData(
        remoteMessage.data as Record<string, string>,
      );
      if (nav) {
        (navigation as any).navigate(nav.screen, nav.params);
      }
    });

    unsubscribeRef.current.push(bgUnsub);

    return () => {
      bgUnsub();
    };
  }, [navigation]);

  return { fcmToken, isPermissionGranted, requestPermission };
}
