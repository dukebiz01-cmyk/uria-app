import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';

import { usersApi } from '../../api/users.api';
import { useUserStore } from '../../store/user.store';
import { useLocation } from '../../hooks/useLocation';
import { Avatar } from '../../components/common/Avatar';
import { TierBadge } from '../../components/common/Badge';
import { Spinner, Skeleton } from '../../components/common/LoadingOverlay';
import { ErrorView } from '../../components/common/ErrorBoundary';
import { colors } from '../../constants/colors';
import { formatDistance } from '../../utils/format';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { UserProfile } from '../../types/api.types';
import { AppStackParamList, TabParamList } from '../../navigation/AppNavigator';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, 'Home'>,
  NativeStackScreenProps<AppStackParamList>
>;

const PAGE_SIZE = 20;

// ─── 유저 카드 컴포넌트 ────────────────────────────────────────────────────────

interface UserCardProps {
  user: UserProfile;
  onPress: () => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onPress }) => (
  <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
    <Avatar uri={user.photos[0]} nickname={user.nickname} size="lg" />
    <View style={styles.cardInfo}>
      <View style={styles.cardNameRow}>
        <Text style={styles.cardName}>{user.nickname}</Text>
        <Text style={styles.cardAge}>{user.age}세</Text>
      </View>
      <TierBadge tier={user.passportTier} />
      {user.bio ? (
        <Text style={styles.cardBio} numberOfLines={2}>
          {user.bio}
        </Text>
      ) : null}
    </View>
    <View style={styles.cardRight}>
      {user.distanceM !== undefined && (
        <Text style={styles.cardDistance}>
          {formatDistance(user.distanceM)}
        </Text>
      )}
      {user.isTonightMode && (
        <View style={styles.tonightDot} />
      )}
    </View>
  </TouchableOpacity>
);

// ─── 스켈레톤 카드 ─────────────────────────────────────────────────────────────

const UserCardSkeleton: React.FC = () => (
  <View style={[styles.card, styles.skeletonCard]}>
    <Skeleton width={72} height={72} borderRadius={36} />
    <View style={styles.cardInfo}>
      <Skeleton width={100} height={16} />
      <Skeleton width={60} height={20} style={{ marginTop: 6 }} />
      <Skeleton width={140} height={12} style={{ marginTop: 6 }} />
    </View>
  </View>
);

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const HomeScreen: React.FC<Props> = ({ navigation }) => {
  const profile = useUserStore((s) => s.profile);
  const setTonightMode = useUserStore((s) => s.setTonightMode);

  const { getCurrentLocation } = useLocation();

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isTonightMode = profile?.isTonightMode ?? false;

  const fetchUsers = useCallback(async (p = 1, refresh = false) => {
    if (refresh) setIsRefreshing(true);
    else if (p === 1) setIsLoading(true);
    else setIsLoadingMore(true);

    setError(null);

    try {
      const loc = await getCurrentLocation();
      if (!loc) {
        setError('위치 정보를 가져올 수 없습니다.');
        return;
      }

      const result = await usersApi.getNearbyUsers({
        lat: loc.coords.lat,
        lng: loc.coords.lng,
        page: p,
        pageSize: PAGE_SIZE,
        tonightOnly: true,
      });

      setUsers((prev) => (p === 1 ? result.items : [...prev, ...result.items]));
      setTotal(result.total);
      setPage(p);
    } catch (e) {
      const err = parseApiError(e);
      setError(getErrorMessage(err));
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
      setIsLoadingMore(false);
    }
  }, [getCurrentLocation]);

  useEffect(() => {
    if (isTonightMode) {
      fetchUsers(1);
    } else {
      setIsLoading(false);
    }
  }, [isTonightMode]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleToggleTonightMode = async (val: boolean) => {
    try {
      await setTonightMode(val);
      if (val) fetchUsers(1);
    } catch {
      Alert.alert('오류', 'TONIGHT MODE 변경에 실패했습니다.');
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && users.length < total) {
      fetchUsers(page + 1);
    }
  };

  const handleRefresh = () => fetchUsers(1, true);

  // ─── 렌더 ───────────────────────────────────────────────────────────────────

  const renderHeader = () => (
    <View style={styles.listHeader}>
      <Text style={styles.nearbyCount}>
        {isTonightMode ? `주변 ${total}명` : ''}
      </Text>
    </View>
  );

  const renderItem = ({ item }: { item: UserProfile }) => (
    <UserCard
      user={item}
      onPress={() =>
        (navigation as any).navigate('UserDetail', { userId: item.id })
      }
    />
  );

  const renderFooter = () => {
    if (!isLoadingMore) return null;
    return <Spinner size="small" />;
  };

  return (
    <SafeAreaView style={styles.safe}>
      {/* 헤더 */}
      <View style={styles.header}>
        <Text style={styles.logo}>URIA</Text>
        <View style={styles.tonightToggle}>
          <View style={[styles.tonightDotSmall, isTonightMode && styles.tonightDotActive]} />
          <Text style={[styles.tonightLabel, isTonightMode && styles.tonightLabelActive]}>
            TONIGHT
          </Text>
          <Switch
            value={isTonightMode}
            onValueChange={handleToggleTonightMode}
            trackColor={{ false: colors.border, true: colors.tealAlpha10 }}
            thumbColor={isTonightMode ? colors.teal : colors.textFaint}
          />
        </View>
      </View>

      {/* 본문 */}
      {!isTonightMode ? (
        <View style={styles.inactiveContainer}>
          <Text style={styles.inactiveEmoji}>🌙</Text>
          <Text style={styles.inactiveTitle}>TONIGHT MODE 꺼짐</Text>
          <Text style={styles.inactiveDesc}>
            TONIGHT MODE를 활성화하면 주변의 활성 유저를 만날 수 있습니다.
          </Text>
        </View>
      ) : error ? (
        <ErrorView message={error} onRetry={() => fetchUsers(1)} />
      ) : isLoading ? (
        <View style={styles.skeletonList}>
          {[...Array(5)].map((_, i) => (
            <UserCardSkeleton key={i} />
          ))}
        </View>
      ) : users.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyEmoji}>🔍</Text>
          <Text style={styles.emptyTitle}>주변에 활성 유저가 없습니다</Text>
          <Text style={styles.emptyDesc}>
            TONIGHT MODE를 켠 유저가 주변에 없어요. 잠시 후 다시 확인해보세요.
          </Text>
        </View>
      ) : (
        <FlatList
          data={users}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          ListHeaderComponent={renderHeader}
          ListFooterComponent={renderFooter}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.4}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor={colors.primary}
              colors={[colors.primary]}
            />
          }
        />
      )}
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  logo: {
    fontSize: 22,
    fontWeight: '900',
    color: colors.primary,
    letterSpacing: 3,
  },
  tonightToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  tonightDotSmall: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.border,
  },
  tonightDotActive: { backgroundColor: colors.teal },
  tonightLabel: { fontSize: 13, color: colors.textFaint, fontWeight: '600' },
  tonightLabelActive: { color: colors.teal },

  listContent: { paddingVertical: 8, paddingBottom: 20 },
  listHeader: { paddingHorizontal: 20, paddingVertical: 8 },
  nearbyCount: { fontSize: 13, color: colors.textMuted },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  skeletonCard: { paddingVertical: 16 },
  cardInfo: { flex: 1, gap: 6 },
  cardNameRow: { flexDirection: 'row', alignItems: 'baseline', gap: 6 },
  cardName: { fontSize: 16, fontWeight: '700', color: colors.text },
  cardAge: { fontSize: 14, color: colors.textMuted },
  cardBio: { fontSize: 13, color: colors.textFaint, lineHeight: 18 },
  cardRight: { alignItems: 'flex-end', gap: 6 },
  cardDistance: { fontSize: 12, color: colors.textFaint },
  tonightDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.teal,
  },

  skeletonList: { paddingTop: 8 },

  inactiveContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    gap: 16,
  },
  inactiveEmoji: { fontSize: 56 },
  inactiveTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
  inactiveDesc: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 22,
  },

  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    gap: 12,
  },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: { fontSize: 17, fontWeight: '600', color: colors.text },
  emptyDesc: {
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 20,
  },
});
