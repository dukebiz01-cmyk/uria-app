import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { useChatStore } from '../../store/chat.store';
import { useAuthStore } from '../../store/auth.store';
import { momentsApi } from '../../api/moments.api';
import { chatApi } from '../../api/chat.api';
import { MessageBubble } from '../../components/chat/MessageBubble';
import { ChatInput } from '../../components/chat/ChatInput';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { ChatMessage } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'ChatRoom'>;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const ChatRoomScreen: React.FC<Props> = ({ route, navigation }) => {
  const { roomId, partnerName } = route.params;
  const myId = useAuthStore((s) => s.userId) ?? '';

  const messages = useChatStore((s) => s.messages[roomId] ?? []);
  const hasMore = useChatStore((s) => s.hasMoreMessages[roomId] ?? false);
  const isLoadingMessages = useChatStore((s) => s.loadingMessages[roomId] ?? false);
  const fetchMessages = useChatStore((s) => s.fetchMessages);
  const loadMoreMessages = useChatStore((s) => s.loadMoreMessages);
  const sendMessage = useChatStore((s) => s.sendMessage);
  const markRoomAsRead = useChatStore((s) => s.markRoomAsRead);

  const [isSending, setIsSending] = useState(false);
  const flatListRef = useRef<FlatList<ChatMessage>>(null);

  // 헤더에 MOMENT 버튼 추가
  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={styles.momentHeaderBtn}
          onPress={handleMomentRequest}
        >
          <Text style={styles.momentHeaderText}>🌙 MOMENT</Text>
        </TouchableOpacity>
      ),
    });
  }, [navigation]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchMessages(roomId);
    markRoomAsRead(roomId);

    return () => {
      // 읽음 처리 API 호출
      const lastMsg = messages[0];
      if (lastMsg) {
        chatApi.markAsRead(roomId, lastMsg.id).catch(() => {});
      }
    };
  }, [roomId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSend = useCallback(
    async (text: string) => {
      if (isSending) return;
      setIsSending(true);
      try {
        await sendMessage(roomId, text, 'text');
      } catch (e) {
        const err = parseApiError(e);
        Alert.alert('전송 실패', getErrorMessage(err));
      } finally {
        setIsSending(false);
      }
    },
    [roomId, sendMessage, isSending],
  );

  const handleMomentRequest = useCallback(async () => {
    Alert.alert(
      'MOMENT 요청',
      `${partnerName}님에게 실제 만남을 요청합니다.\n상대방이 수락하면 30분 타이머가 시작됩니다.`,
      [
        { text: '취소', style: 'cancel' },
        {
          text: '요청하기',
          onPress: async () => {
            try {
              const moment = await momentsApi.requestMoment(roomId);
              // 채팅방에 시스템 메시지로 MOMENT 요청 표시는 서버 WebSocket에서 처리
              (navigation as any).navigate('MomentCheckin', {
                momentId: moment.id,
                roomId,
              });
            } catch (e) {
              const err = parseApiError(e);
              Alert.alert('오류', getErrorMessage(err));
            }
          },
        },
      ],
    );
  }, [partnerName, roomId, navigation]);

  const handleLoadMore = useCallback(() => {
    if (hasMore && !isLoadingMessages) {
      loadMoreMessages(roomId);
    }
  }, [hasMore, isLoadingMessages, roomId, loadMoreMessages]);

  const renderMessage = useCallback(
    ({ item, index }: { item: ChatMessage; index: number }) => {
      const isMine = item.senderId === myId;
      // 이전 메시지와 같은 시각이면 시간 숨김
      const nextMsg = messages[index - 1]; // inverted 이므로 index-1이 더 최근
      const showTime =
        !nextMsg ||
        nextMsg.senderId !== item.senderId;

      return <MessageBubble message={item} isMine={isMine} showTime={showTime} />;
    },
    [myId, messages],
  );

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 88 : 0}
      >
        {isLoadingMessages && messages.length === 0 ? (
          <Spinner />
        ) : (
          <>
            <FlatList
              ref={flatListRef}
              data={messages}
              keyExtractor={(item) => item.id}
              renderItem={renderMessage}
              inverted
              onEndReached={handleLoadMore}
              onEndReachedThreshold={0.3}
              contentContainerStyle={styles.messageList}
              ListHeaderComponent={
                isLoadingMessages ? (
                  <View style={styles.loadingMore}>
                    <Text style={styles.loadingMoreText}>...</Text>
                  </View>
                ) : null
              }
              ListEmptyComponent={
                <View style={styles.emptyContainer}>
                  <Text style={styles.emptyText}>
                    첫 메시지를 보내보세요 💜
                  </Text>
                </View>
              }
            />
            <ChatInput
              onSend={handleSend}
              isLoading={isSending}
              placeholder={`${partnerName}님에게 메시지...`}
            />
          </>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  messageList: { paddingVertical: 12 },
  loadingMore: { alignItems: 'center', paddingVertical: 8 },
  loadingMoreText: { color: colors.textFaint, fontSize: 20 },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: { fontSize: 14, color: colors.textMuted },
  momentHeaderBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: colors.tealAlpha10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.teal,
  },
  momentHeaderText: { fontSize: 13, color: colors.teal, fontWeight: '600' },
});
