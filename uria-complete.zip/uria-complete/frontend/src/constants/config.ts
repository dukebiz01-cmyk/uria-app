import { Platform } from 'react-native';

// ✅ URL 프리픽스 수정: /v1 → /api (백엔드 라우터와 일치)
const ENV = {
  development: {
    API_BASE_URL: 'http://10.0.2.2:3000/api',   // Android 에뮬레이터
    WS_BASE_URL:  'ws://10.0.2.2:3000',
  },
  production: {
    API_BASE_URL: 'https://uria-api.onrender.com/api', // Render 배포 URL
    WS_BASE_URL:  'wss://uria-api.onrender.com',
  },
};

const isDev = __DEV__;
const env = isDev ? ENV.development : ENV.production;

export const config = {
  ...env,
  PORTONE_IMP_CODE:   'imp00000000',
  PORTONE_PG_PROVIDER:'kakaopay',
  API_TIMEOUT:        15_000,
  WS_MAX_RETRIES:     5,
  WS_INITIAL_RETRY_DELAY: 1_000,
  WS_MAX_RETRY_DELAY: 30_000,
  LOCATION_TIMEOUT:   15_000,
  LOCATION_MAX_AGE:   10_000,
  LOCATION_ACCURACY:  Platform.OS === 'ios' ? 'best' : 'high',
  PAGE_SIZE:          20,
  MOMENT_TIMER_MINUTES: 30,
  SIGNAL_EXPIRY_HOURS:  12,
} as const;
