import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { colors } from '../../constants/colors';
import { PassportTier } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface TrustScoreBarProps {
  score: number; // 0~100
  tier: PassportTier;
  animated?: boolean;
}

// ─── 티어별 색상 ──────────────────────────────────────────────────────────────

const TIER_COLOR: Record<PassportTier, string> = {
  Starter: colors.textMuted,
  Silver: '#C0C0C0',
  Gold: colors.gold,
  Platinum: colors.teal,
};

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const TrustScoreBar: React.FC<TrustScoreBarProps> = ({
  score,
  tier,
  animated = true,
}) => {
  const animValue = useRef(new Animated.Value(0)).current;
  const barColor = TIER_COLOR[tier];

  useEffect(() => {
    if (animated) {
      Animated.timing(animValue, {
        toValue: score / 100,
        duration: 800,
        useNativeDriver: false,
      }).start();
    } else {
      animValue.setValue(score / 100);
    }
  }, [score, animated]); // eslint-disable-line react-hooks/exhaustive-deps

  const widthInterpolated = animValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.label}>Trust Score</Text>
        <Text style={[styles.score, { color: barColor }]}>
          {score.toFixed(1)}
        </Text>
      </View>

      <View style={styles.track}>
        <Animated.View
          style={[
            styles.fill,
            { width: widthInterpolated, backgroundColor: barColor },
          ]}
        />
      </View>

      {/* 구간 표시 */}
      <View style={styles.milestones}>
        {[0, 25, 50, 75, 100].map((v) => (
          <Text key={v} style={styles.milestone}>
            {v}
          </Text>
        ))}
      </View>
    </View>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { gap: 8 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: { fontSize: 13, color: colors.textMuted, fontWeight: '500' },
  score: { fontSize: 24, fontWeight: '800' },
  track: {
    height: 8,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 4,
    overflow: 'hidden',
  },
  fill: { height: '100%', borderRadius: 4 },
  milestones: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  milestone: { fontSize: 10, color: colors.textFaint },
});
