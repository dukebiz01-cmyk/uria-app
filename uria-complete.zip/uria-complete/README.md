# URIA — 완성 소스코드 설정 가이드

## 버그 수정 내역
- ✅ BUG1: 코인 이중 차감 수정 (wallet.service.js)
- ✅ BUG2: FCM push token 해시 버그 수정 (fcm.service.js + 011_push_tokens.sql)
- ✅ BUG3: Signal escrow race condition 수정 (signals.service.js)
- ✅ BUG4: SignalStatus 타입 불일치 수정 (api.types.ts)
- ✅ GAP1: WebSocket URL 불일치 수정 (useWebSocket.ts)
- ✅ URL:  API 프리픽스 /v1 → /api 수정 (config.ts)

---

## Step 1: GitHub 레포 생성 후 업로드 (5분)

```bash
# 이 폴더 전체를 GitHub에 업로드
git init
git add .
git commit -m "URIA MVP v1.0 — bugs fixed"
git remote add origin https://github.com/YOUR_USERNAME/uria-app.git
git push -u origin main
```

---

## Step 2: Render 배포 (10분)

1. render.com 접속
2. New → Blueprint → GitHub 레포 연결
3. `render.yaml` 자동 감지됨 → Apply
4. 환경변수 추가 (필수):
   - `JWT_ACCESS_SECRET`: 랜덤 32자 이상
   - `JWT_REFRESH_SECRET`: 랜덤 32자 이상
5. Deploy 클릭
6. DB 마이그레이션 실행:
   ```bash
   # Render Shell 탭에서
   node migrate.js
   ```

---

## Step 3: GitHub Secrets 설정 (5분)
`GITHUB_SECRETS.md` 파일 참고

---

## Step 4: APK 빌드 확인 (20분)
- GitHub → Actions → Build Android APK → Run workflow
- 완료 후 Artifacts에서 APK 다운로드

---

## Step 5: 앱에서 직접 테스트
1. APK를 Android 폰에 설치
2. 가입 → Tonight Mode ON → Signal 전송 → 수락 → 채팅 전체 플로우 확인

---

## 추가 설정 (선택)

### Firebase FCM 설정 (푸시 알림)
1. firebase.google.com → 프로젝트 생성
2. 서비스 계정 JSON 다운로드
3. Render 환경변수에 추가:
   - `FIREBASE_PROJECT_ID`
   - `FIREBASE_CLIENT_EMAIL`
   - `FIREBASE_PRIVATE_KEY`

### S3 사진 업로드 설정
1. AWS S3 버킷 생성
2. Render 환경변수에 추가:
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `S3_BUCKET_NAME`

### PortOne 결제 설정
1. portone.io → 계정 생성 → API 키 발급
2. Render 환경변수에 추가:
   - `PORTONE_API_SECRET`
   - `PORTONE_WEBHOOK_SECRET`

---

## 코인 흐름 검증 (배포 후 필수 확인)

```
시나리오: Signal 전송 → 수락 → Moment 완료
기대 결과: 시작 잔액 - 2코인 = 최종 잔액

시나리오: Signal 전송 → 거절
기대 결과: 시작 잔액 = 최종 잔액 (전액 환불)
```

wallet_ledger 테이블에서 확인:
```sql
SELECT entry_type, amount, balance_after
FROM wallet_ledger
WHERE user_id = 'USER_UUID'
ORDER BY created_at;
```
