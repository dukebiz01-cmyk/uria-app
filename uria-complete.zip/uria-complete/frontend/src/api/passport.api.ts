import apiClient from './client';
import { ApiResponse, Passport } from '../types/api.types';

export const passportApi = {
  /**
   * 내 PASSPORT 조회
   */
  getMyPassport: async (): Promise<Passport> => {
    const { data } = await apiClient.get<ApiResponse<Passport>>(
      '/passport/me',
    );
    return data.data;
  },

  /**
   * 특정 유저의 PASSPORT 조회
   */
  getUserPassport: async (userId: string): Promise<Passport> => {
    const { data } = await apiClient.get<ApiResponse<Passport>>(
      `/passport/${userId}`,
    );
    return data.data;
  },
};
