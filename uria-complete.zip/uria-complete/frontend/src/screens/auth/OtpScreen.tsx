import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { authApi } from '../../api/auth.api';
import { useAuthStore } from '../../store/auth.store';
import { Button } from '../../components/common/Button';
import { colors } from '../../constants/colors';
import { formatPhoneDisplay } from '../../utils/format';
import { getErrorMessage, parseApiError } from '../../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AuthStackParamList, 'Otp'>;

const OTP_LENGTH = 6;
const RESEND_COOLDOWN = 60; // 초

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const OtpScreen: React.FC<Props> = ({ navigation, route }) => {
  const { phone } = route.params;
  const login = useAuthStore((s) => s.login);

  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [cooldown, setCooldown] = useState(RESEND_COOLDOWN);
  const [isResending, setIsResending] = useState(false);

  const inputRef = useRef<TextInput>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 쿨다운 카운트다운
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // OTP 완성 시 자동 제출
  useEffect(() => {
    if (otp.length === OTP_LENGTH) {
      handleVerify();
    }
  }, [otp]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleVerify = async () => {
    if (otp.length !== OTP_LENGTH || isLoading) return;
    setIsLoading(true);

    try {
      const result = await authApi.verifyOtp({ phone, otp });

      await login({
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        userId: result.userId,
      });

      if (result.isNewUser) {
        navigation.navigate('Gender', { userId: result.userId });
      }
      // 기존 유저: RootNavigator가 자동으로 AppNavigator로 전환
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('인증 실패', getErrorMessage(err));
      setOtp('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0 || isResending) return;
    setIsResending(true);

    try {
      await authApi.requestOtp({ phone });
      setCooldown(RESEND_COOLDOWN);
      // 쿨다운 재시작
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setCooldown((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('오류', getErrorMessage(err));
    } finally {
      setIsResending(false);
    }
  };

  // OTP 박스 UI
  const otpDigits = Array.from({ length: OTP_LENGTH }, (_, i) => otp[i] ?? '');

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.content}>
          {/* 헤더 */}
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backText}>← 뒤로</Text>
          </TouchableOpacity>

          <Text style={styles.title}>인증번호 입력</Text>
          <Text style={styles.subtitle}>
            <Text style={styles.phone}>{formatPhoneDisplay(phone)}</Text>
            {'\n'}으로 6자리 인증번호를 보냈습니다.
          </Text>

          {/* 숨겨진 실제 입력 필드 */}
          <TextInput
            ref={inputRef}
            style={styles.hiddenInput}
            value={otp}
            onChangeText={(v) => setOtp(v.replace(/\D/g, '').slice(0, OTP_LENGTH))}
            keyboardType="number-pad"
            autoFocus
            maxLength={OTP_LENGTH}
          />

          {/* OTP 박스 표시 */}
          <TouchableOpacity
            style={styles.otpRow}
            onPress={() => inputRef.current?.focus()}
            activeOpacity={0.9}
          >
            {otpDigits.map((digit, i) => (
              <View
                key={i}
                style={[
                  styles.otpBox,
                  otp.length === i && styles.otpBoxActive,
                  digit && styles.otpBoxFilled,
                ]}
              >
                <Text style={styles.otpDigit}>{digit}</Text>
              </View>
            ))}
          </TouchableOpacity>

          {/* 재전송 */}
          <View style={styles.resendRow}>
            <Text style={styles.resendText}>인증번호를 못 받으셨나요? </Text>
            <TouchableOpacity
              onPress={handleResend}
              disabled={cooldown > 0 || isResending}
            >
              <Text
                style={[
                  styles.resendLink,
                  cooldown > 0 && styles.resendDisabled,
                ]}
              >
                {cooldown > 0 ? `재전송 (${cooldown}s)` : '재전송'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* 확인 버튼 */}
          <Button
            title="확인"
            onPress={handleVerify}
            isLoading={isLoading}
            disabled={otp.length < OTP_LENGTH}
            fullWidth
            size="lg"
            style={styles.submitBtn}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  content: {
    flex: 1,
    padding: 24,
    paddingTop: 16,
    gap: 24,
  },
  backBtn: { marginBottom: 8 },
  backText: { fontSize: 16, color: colors.primary },
  title: { fontSize: 24, fontWeight: '700', color: colors.text },
  subtitle: {
    fontSize: 14,
    color: colors.textMuted,
    lineHeight: 22,
  },
  phone: { color: colors.text, fontWeight: '600' },
  hiddenInput: {
    position: 'absolute',
    opacity: 0,
    width: 0,
    height: 0,
  },
  otpRow: {
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    marginVertical: 8,
  },
  otpBox: {
    width: 46,
    height: 56,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  otpBoxActive: { borderColor: colors.primary },
  otpBoxFilled: { backgroundColor: colors.surfaceAlt },
  otpDigit: { fontSize: 22, fontWeight: '700', color: colors.text },
  resendRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  resendText: { fontSize: 13, color: colors.textMuted },
  resendLink: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  resendDisabled: { color: colors.textFaint },
  submitBtn: { marginTop: 'auto' },
});
