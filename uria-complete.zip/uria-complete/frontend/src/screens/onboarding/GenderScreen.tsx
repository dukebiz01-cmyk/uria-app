import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { Button } from '../../components/common/Button';
import { colors } from '../../constants/colors';
import { Gender } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AuthStackParamList, 'Gender'>;

const GENDER_OPTIONS: { value: Gender; label: string; emoji: string }[] = [
  { value: 'male', label: '남성', emoji: '♂️' },
  { value: 'female', label: '여성', emoji: '♀️' },
  { value: 'other', label: '기타', emoji: '⚧️' },
];

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const GenderScreen: React.FC<Props> = ({ navigation, route }) => {
  const { userId } = route.params;
  const [selected, setSelected] = useState<Gender | null>(null);

  const handleNext = () => {
    if (!selected) return;
    navigation.navigate('Profile', { userId, gender: selected });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.step}>1 / 3</Text>
          <Text style={styles.title}>성별을 알려주세요</Text>
          <Text style={styles.subtitle}>
            주변 유저를 연결할 때 사용됩니다. 나중에 변경할 수 없습니다.
          </Text>
        </View>

        <View style={styles.options}>
          {GENDER_OPTIONS.map((opt) => (
            <TouchableOpacity
              key={opt.value}
              style={[
                styles.optionCard,
                selected === opt.value && styles.optionCardSelected,
              ]}
              onPress={() => setSelected(opt.value)}
              activeOpacity={0.8}
            >
              <Text style={styles.optionEmoji}>{opt.emoji}</Text>
              <Text
                style={[
                  styles.optionLabel,
                  selected === opt.value && styles.optionLabelSelected,
                ]}
              >
                {opt.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Button
          title="다음"
          onPress={handleNext}
          disabled={!selected}
          fullWidth
          size="lg"
        />
      </View>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: {
    flex: 1,
    padding: 24,
    gap: 40,
    justifyContent: 'center',
  },
  header: { gap: 10 },
  step: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  title: { fontSize: 26, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 14, color: colors.textMuted, lineHeight: 21 },
  options: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'center',
  },
  optionCard: {
    flex: 1,
    aspectRatio: 0.85,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  optionCardSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryAlpha10,
  },
  optionEmoji: { fontSize: 36 },
  optionLabel: { fontSize: 16, fontWeight: '600', color: colors.textMuted },
  optionLabelSelected: { color: colors.primary },
});
