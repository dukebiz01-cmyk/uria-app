export const colors = {
  // 배경
  bg: '#0A0A0F',
  surface: '#13131A',
  surfaceAlt: '#1A1A24',
  border: '#2A2A3A',

  // 텍스트
  text: '#F0EFFF',
  textMuted: '#8B8BA0',
  textFaint: '#55556A',

  // 브랜드 & 기능 색상
  primary: '#7C6AF7',       // URIA 브랜드 보라
  primaryHover: '#6355D4',
  teal: '#4ECDC4',          // TONIGHT MODE
  gold: '#FFD166',          // 코인
  accent: '#FF6B6B',        // SIGNAL / 강조
  green: '#06D6A0',         // 성공 / MOMENT
  error: '#FF4757',
  warning: '#FFA502',

  // 투명도 변형
  primaryAlpha10: 'rgba(124, 106, 247, 0.10)',
  primaryAlpha20: 'rgba(124, 106, 247, 0.20)',
  accentAlpha10: 'rgba(255, 107, 107, 0.10)',
  tealAlpha10: 'rgba(78, 205, 196, 0.10)',
  goldAlpha10: 'rgba(255, 209, 102, 0.10)',
  greenAlpha10: 'rgba(6, 214, 160, 0.10)',

  // 오버레이
  overlay: 'rgba(10, 10, 15, 0.7)',
  overlayLight: 'rgba(10, 10, 15, 0.4)',

  // 공통
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
} as const;

export type Color = keyof typeof colors;
