import React, { useState } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { momentsApi } from '../../api/moments.api';
import { Button } from '../../components/common/Button';
import { colors } from '../../constants/colors';
import { parseApiError, getErrorMessage } from '../../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'MomentReview'>;

const REVIEW_TAGS = [
  '매너 있었어요',
  '시간 약속을 잘 지켜요',
  '대화가 즐거웠어요',
  '또 만나고 싶어요',
  '외모가 프로필과 같아요',
  '친절해요',
  '약속 장소에 제시간에 왔어요',
];

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const MomentReviewScreen: React.FC<Props> = ({ route, navigation }) => {
  const { momentId } = route.params;

  const [rating, setRating] = useState<1 | 2 | 3 | 4 | 5 | 0>(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag],
    );
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      Alert.alert('별점 필요', '별점을 선택해주세요.');
      return;
    }

    setIsSubmitting(true);
    try {
      await momentsApi.submitReview({
        momentId,
        rating: rating as 1 | 2 | 3 | 4 | 5,
        tags: selectedTags,
        comment: comment.trim() || undefined,
      });

      Alert.alert('후기 완료', '후기가 제출되었습니다. 감사합니다!', [
        {
          text: '확인',
          onPress: () => navigation.popToTop(),
        },
      ]);
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('오류', getErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Text style={styles.emoji}>🌙</Text>
          <Text style={styles.title}>MOMENT 후기</Text>
          <Text style={styles.subtitle}>
            오늘의 만남은 어떠셨나요?{'\n'}후기는 SCORE PASSPORT에 반영됩니다.
          </Text>
        </View>

        {/* 별점 */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>별점</Text>
          <View style={styles.stars}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity
                key={star}
                onPress={() => setRating(star as 1 | 2 | 3 | 4 | 5)}
              >
                <Text
                  style={[
                    styles.star,
                    star <= rating && styles.starFilled,
                  ]}
                >
                  ★
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 태그 선택 */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>좋았던 점 (복수 선택 가능)</Text>
          <View style={styles.tags}>
            {REVIEW_TAGS.map((tag) => {
              const selected = selectedTags.includes(tag);
              return (
                <TouchableOpacity
                  key={tag}
                  style={[styles.tag, selected && styles.tagSelected]}
                  onPress={() => toggleTag(tag)}
                >
                  <Text style={[styles.tagText, selected && styles.tagTextSelected]}>
                    {tag}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* 코멘트 */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>코멘트 (선택)</Text>
          <TextInput
            style={styles.commentInput}
            placeholder="자유롭게 후기를 남겨주세요..."
            placeholderTextColor={colors.textFaint}
            value={comment}
            onChangeText={setComment}
            maxLength={300}
            multiline
            numberOfLines={4}
          />
          <Text style={styles.charCount}>{comment.length}/300</Text>
        </View>

        <Button
          title="후기 제출"
          onPress={handleSubmit}
          isLoading={isSubmitting}
          disabled={rating === 0}
          fullWidth
          size="lg"
        />

        <TouchableOpacity
          style={styles.skipBtn}
          onPress={() => navigation.popToTop()}
        >
          <Text style={styles.skipText}>건너뛰기</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 24, gap: 28, flexGrow: 1 },
  header: { alignItems: 'center', gap: 10 },
  emoji: { fontSize: 48 },
  title: { fontSize: 24, fontWeight: '800', color: colors.text },
  subtitle: {
    fontSize: 14,
    color: colors.textMuted,
    lineHeight: 22,
    textAlign: 'center',
  },

  section: { gap: 12 },
  sectionLabel: { fontSize: 14, fontWeight: '600', color: colors.textMuted },

  stars: { flexDirection: 'row', gap: 8, justifyContent: 'center' },
  star: { fontSize: 40, color: colors.border },
  starFilled: { color: colors.gold },

  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
  },
  tagSelected: {
    borderColor: colors.green,
    backgroundColor: colors.greenAlpha10,
  },
  tagText: { fontSize: 13, color: colors.textMuted },
  tagTextSelected: { color: colors.green, fontWeight: '600' },

  commentInput: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: colors.border,
    padding: 14,
    fontSize: 14,
    color: colors.text,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  charCount: { fontSize: 11, color: colors.textFaint, textAlign: 'right' },

  skipBtn: { alignItems: 'center', paddingVertical: 8 },
  skipText: { fontSize: 14, color: colors.textFaint },
});
