import React, { useEffect, useState } from 'react';
import {
  FlatList,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList, TabParamList } from '../../navigation/AppNavigator';
import { useChatStore } from '../../store/chat.store';
import { useAuthStore } from '../../store/auth.store';
import { Avatar } from '../../components/common/Avatar';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { formatChatTime } from '../../utils/format';
import { ChatRoom } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, 'Chat'>,
  NativeStackScreenProps<AppStackParamList>
>;

// ─── 채팅방 행 컴포넌트 ────────────────────────────────────────────────────────

interface ChatRoomItemProps {
  room: ChatRoom;
  myId: string;
  onPress: () => void;
}

const ChatRoomItem: React.FC<ChatRoomItemProps> = ({ room, myId, onPress }) => {
  const partner = room.participants.find((p) => p.id !== myId);
  const lastMsg = room.lastMessage;
  const hasUnread = room.unreadCount > 0;

  return (
    <TouchableOpacity style={styles.roomItem} onPress={onPress} activeOpacity={0.8}>
      <Avatar uri={partner?.photos[0]} nickname={partner?.nickname} size="md" />

      <View style={styles.roomInfo}>
        <View style={styles.roomTopRow}>
          <Text style={[styles.roomName, hasUnread && styles.roomNameBold]}>
            {partner?.nickname ?? '상대방'}
          </Text>
          {lastMsg && (
            <Text style={styles.roomTime}>{formatChatTime(lastMsg.createdAt)}</Text>
          )}
        </View>

        <View style={styles.roomBottomRow}>
          {lastMsg ? (
            <Text
              style={[styles.lastMessage, hasUnread && styles.lastMessageBold]}
              numberOfLines={1}
            >
              {lastMsg.type === 'image'
                ? '📷 사진'
                : lastMsg.type === 'moment_request'
                  ? '🌙 MOMENT 요청'
                  : lastMsg.content}
            </Text>
          ) : (
            <Text style={styles.lastMessage}>채팅을 시작해보세요</Text>
          )}

          {hasUnread && (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadText}>
                {room.unreadCount > 99 ? '99+' : room.unreadCount}
              </Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const ChatListScreen: React.FC<Props> = ({ navigation }) => {
  const rooms = useChatStore((s) => s.rooms);
  const isLoading = useChatStore((s) => s.isLoadingRooms);
  const fetchRooms = useChatStore((s) => s.fetchRooms);
  const myId = useAuthStore((s) => s.userId) ?? '';

  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    fetchRooms();
  }, [fetchRooms]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchRooms();
    setIsRefreshing(false);
  };

  if (isLoading && rooms.length === 0) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.title}>채팅</Text>
      </View>

      <FlatList
        data={rooms}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ChatRoomItem
            room={item}
            myId={myId}
            onPress={() => {
              const partner = item.participants.find((p) => p.id !== myId);
              (navigation as any).navigate('ChatRoom', {
                roomId: item.id,
                partnerName: partner?.nickname ?? '채팅',
              });
            }}
          />
        )}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyEmoji}>💬</Text>
            <Text style={styles.emptyTitle}>채팅방이 없습니다</Text>
            <Text style={styles.emptyDesc}>
              상대의 SIGNAL을 수락하거나{'\n'}내 SIGNAL이 수락되면 채팅이 시작됩니다.
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: { fontSize: 22, fontWeight: '800', color: colors.text },
  roomItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  roomInfo: { flex: 1, gap: 4 },
  roomTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  roomName: { fontSize: 15, color: colors.text },
  roomNameBold: { fontWeight: '700' },
  roomTime: { fontSize: 11, color: colors.textFaint },
  roomBottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lastMessage: { fontSize: 13, color: colors.textMuted, flex: 1 },
  lastMessageBold: { color: colors.text, fontWeight: '600' },
  unreadBadge: {
    backgroundColor: colors.accent,
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  unreadText: { fontSize: 11, color: colors.white, fontWeight: '700' },
  emptyContainer: {
    paddingTop: 100,
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 32,
  },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: { fontSize: 17, fontWeight: '600', color: colors.text },
  emptyDesc: {
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 20,
  },
});
