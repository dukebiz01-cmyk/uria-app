import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authApi } from '../api/auth.api';
import { storage } from '../utils/storage';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  userId: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

interface AuthActions {
  login: (params: {
    accessToken: string;
    refreshToken: string;
    userId: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  refreshTokens: () => Promise<boolean>;
  clearError: () => void;
  setLoading: (loading: boolean) => void;
  /** 앱 시작 시 AsyncStorage에서 토큰 복원 */
  hydrate: () => Promise<void>;
}

type AuthStore = AuthState & AuthActions;

// ─── 초기 상태 ────────────────────────────────────────────────────────────────

const initialState: AuthState = {
  accessToken: null,
  refreshToken: null,
  userId: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

// ─── 스토어 ───────────────────────────────────────────────────────────────────

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      ...initialState,

      login: async ({ accessToken, refreshToken, userId }) => {
        await storage.saveTokens(accessToken, refreshToken);
        await storage.setItem(storage.keys.USER_ID, userId);

        set({
          accessToken,
          refreshToken,
          userId,
          isAuthenticated: true,
          error: null,
        });
      },

      logout: async () => {
        const { refreshToken } = get();

        // 서버 측 토큰 무효화 (실패해도 로컬은 초기화)
        if (refreshToken) {
          try {
            await authApi.logout(refreshToken);
          } catch {
            // 무시
          }
        }

        await storage.clearTokens();
        set({ ...initialState });
      },

      refreshTokens: async () => {
        const { refreshToken } = get();
        if (!refreshToken) return false;

        try {
          set({ isLoading: true });
          const result = await authApi.refreshToken(refreshToken);
          await storage.saveTokens(result.accessToken, result.refreshToken);

          set({
            accessToken: result.accessToken,
            refreshToken: result.refreshToken,
            isLoading: false,
          });
          return true;
        } catch {
          await storage.clearTokens();
          set({ ...initialState });
          return false;
        }
      },

      hydrate: async () => {
        try {
          set({ isLoading: true });
          const { accessToken, refreshToken } = await storage.getTokens();
          const userId = await storage.getItem(storage.keys.USER_ID);

          if (accessToken && refreshToken && userId) {
            set({
              accessToken,
              refreshToken,
              userId,
              isAuthenticated: true,
              isLoading: false,
            });
          } else {
            set({ ...initialState, isLoading: false });
          }
        } catch {
          set({ ...initialState, isLoading: false });
        }
      },

      clearError: () => set({ error: null }),
      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'uria-auth',
      storage: createJSONStorage(() => AsyncStorage),
      // 토큰은 AsyncStorage 래퍼로 직접 관리하므로 persist에서는 제외
      partialize: (state) => ({
        userId: state.userId,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
);
