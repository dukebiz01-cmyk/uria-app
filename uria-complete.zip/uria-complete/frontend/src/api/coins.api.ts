import apiClient from './client';
import {
  ApiResponse,
  CoinPackage,
  CoinPurchaseBody,
  CoinTransaction,
  PaginatedResponse,
} from '../types/api.types';

export const coinsApi = {
  /**
   * 코인 패키지 목록
   */
  getPackages: async (): Promise<CoinPackage[]> => {
    const { data } = await apiClient.get<ApiResponse<CoinPackage[]>>(
      '/coins/packages',
    );
    return data.data;
  },

  /**
   * 포트원 결제 후 코인 구매 확정
   */
  purchase: async (
    body: CoinPurchaseBody,
  ): Promise<{ balance: number; transaction: CoinTransaction }> => {
    const { data } = await apiClient.post<
      ApiResponse<{ balance: number; transaction: CoinTransaction }>
    >('/coins/purchase', body);
    return data.data;
  },

  /**
   * 코인 잔액 조회
   */
  getBalance: async (): Promise<number> => {
    const { data } = await apiClient.get<ApiResponse<{ balance: number }>>(
      '/coins/balance',
    );
    return data.data.balance;
  },

  /**
   * 코인 사용 내역
   */
  getTransactions: async (
    page = 1,
    pageSize = 20,
  ): Promise<PaginatedResponse<CoinTransaction>> => {
    const { data } = await apiClient.get<
      ApiResponse<PaginatedResponse<CoinTransaction>>
    >('/coins/transactions', { params: { page, pageSize } });
    return data.data;
  },
};
