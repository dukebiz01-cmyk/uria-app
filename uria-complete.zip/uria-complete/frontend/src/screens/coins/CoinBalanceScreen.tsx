import React, { useEffect, useState } from 'react';
import {
  FlatList,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { coinsApi } from '../../api/coins.api';
import { useUserStore } from '../../store/user.store';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { formatCoin, formatDate } from '../../utils/format';
import { CoinTransaction } from '../../types/api.types';
import { parseApiError, getErrorMessage } from '../../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'CoinBalance'>;

// ─── 거래 내역 행 ─────────────────────────────────────────────────────────────

const TransactionItem: React.FC<{ tx: CoinTransaction }> = ({ tx }) => {
  const isPositive = tx.amount > 0;
  return (
    <View style={styles.txItem}>
      <View style={styles.txLeft}>
        <Text style={styles.txDesc}>{tx.description}</Text>
        <Text style={styles.txDate}>{formatDate(tx.createdAt, 'YYYY.MM.DD HH:mm')}</Text>
      </View>
      <View style={styles.txRight}>
        <Text style={[styles.txAmount, isPositive ? styles.txPositive : styles.txNegative]}>
          {isPositive ? '+' : ''}{formatCoin(tx.amount)}
        </Text>
        <Text style={styles.txBalance}>잔액 {formatCoin(tx.balanceAfter)}</Text>
      </View>
    </View>
  );
};

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const CoinBalanceScreen: React.FC<Props> = ({ navigation }) => {
  const profile = useUserStore((s) => s.profile);
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [balance, setBalance] = useState(profile?.coinBalance ?? 0);

  useEffect(() => {
    const load = async () => {
      try {
        const [bal, txResult] = await Promise.all([
          coinsApi.getBalance(),
          coinsApi.getTransactions(),
        ]);
        setBalance(bal);
        setTransactions(txResult.items);
      } catch (e) {
        const err = parseApiError(e);
        console.error(getErrorMessage(err));
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      {/* 잔액 카드 */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>보유 코인</Text>
        <Text style={styles.balanceAmount}>{formatCoin(balance)}</Text>
        <TouchableOpacity
          style={styles.chargeBtn}
          onPress={() => navigation.navigate('CoinPurchase')}
        >
          <Text style={styles.chargeBtnText}>코인 충전하기</Text>
        </TouchableOpacity>
      </View>

      {/* 거래 내역 */}
      <Text style={styles.txTitle}>사용 내역</Text>

      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <TransactionItem tx={item} />}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>거래 내역이 없습니다</Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  balanceCard: {
    margin: 16,
    padding: 24,
    backgroundColor: colors.surface,
    borderRadius: 20,
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: colors.goldAlpha10,
  },
  balanceLabel: { fontSize: 13, color: colors.textMuted },
  balanceAmount: { fontSize: 44, fontWeight: '900', color: colors.gold },
  chargeBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: colors.goldAlpha10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.gold,
  },
  chargeBtnText: { fontSize: 14, fontWeight: '700', color: colors.gold },

  txTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textMuted,
    paddingHorizontal: 20,
    marginBottom: 4,
  },
  listContent: { flexGrow: 1 },
  txItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  txLeft: { flex: 1, gap: 3 },
  txRight: { alignItems: 'flex-end', gap: 3 },
  txDesc: { fontSize: 14, color: colors.text },
  txDate: { fontSize: 11, color: colors.textFaint },
  txAmount: { fontSize: 16, fontWeight: '700' },
  txPositive: { color: colors.green },
  txNegative: { color: colors.accent },
  txBalance: { fontSize: 11, color: colors.textFaint },
  emptyContainer: { paddingTop: 60, alignItems: 'center' },
  emptyText: { fontSize: 14, color: colors.textMuted },
});
