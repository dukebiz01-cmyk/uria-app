import React, { useEffect, useState } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { coinsApi } from '../../api/coins.api';
import { useUserStore } from '../../store/user.store';
import { Button } from '../../components/common/Button';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { formatCoin, formatKRW } from '../../utils/format';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { CoinPackage } from '../../types/api.types';
import { config } from '../../constants/config';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'CoinPurchase'>;

// ─── 패키지 카드 ──────────────────────────────────────────────────────────────

interface PackageCardProps {
  pkg: CoinPackage;
  isSelected: boolean;
  onSelect: () => void;
}

const PackageCard: React.FC<PackageCardProps> = ({ pkg, isSelected, onSelect }) => (
  <TouchableOpacity
    style={[styles.packageCard, isSelected && styles.packageCardSelected]}
    onPress={onSelect}
    activeOpacity={0.8}
  >
    {pkg.isPopular && (
      <View style={styles.popularBadge}>
        <Text style={styles.popularText}>인기</Text>
      </View>
    )}

    <Text style={styles.packageLabel}>{pkg.label}</Text>
    <Text style={styles.packageCoins}>{formatCoin(pkg.coins)}</Text>
    {pkg.bonusCoins ? (
      <Text style={styles.packageBonus}>+{pkg.bonusCoins} 보너스</Text>
    ) : null}
    <Text style={styles.packagePrice}>{formatKRW(pkg.priceKRW)}</Text>

    <View style={[styles.selectCircle, isSelected && styles.selectCircleActive]}>
      {isSelected && <View style={styles.selectDot} />}
    </View>
  </TouchableOpacity>
);

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const CoinPurchaseScreen: React.FC<Props> = ({ navigation }) => {
  const updateCoinBalance = useUserStore((s) => s.updateCoinBalance);
  const profile = useUserStore((s) => s.profile);

  const [packages, setPackages] = useState<CoinPackage[]>([]);
  const [selectedPkg, setSelectedPkg] = useState<CoinPackage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPurchasing, setIsPurchasing] = useState(false);

  useEffect(() => {
    coinsApi
      .getPackages()
      .then((pkgs) => {
        setPackages(pkgs);
        // 기본 선택: 인기 또는 중간
        const popular = pkgs.find((p) => p.isPopular) ?? pkgs[1] ?? pkgs[0];
        setSelectedPkg(popular ?? null);
      })
      .catch(() => {
        // 폴백 패키지
        const fallback: CoinPackage[] = [
          { id: '10c', coins: 10, priceKRW: 1200, label: '10코인' },
          {
            id: '30c',
            coins: 30,
            priceKRW: 3300,
            label: '30코인',
            isPopular: true,
          },
          {
            id: '100c',
            coins: 100,
            priceKRW: 9900,
            label: '100코인',
            bonusCoins: 10,
          },
        ];
        setPackages(fallback);
        setSelectedPkg(fallback[1]);
      })
      .finally(() => setIsLoading(false));
  }, []);

  /**
   * 포트원 결제 흐름:
   * 1. IMP.request_pay() 호출 → 포트원 결제창
   * 2. 성공 시 imp_uid 반환
   * 3. 서버에 imp_uid + packageId 전송 → 검증 + 코인 지급
   *
   * React Native에서는 WebView 또는 포트원 RN SDK 사용.
   * 아래는 실제 SDK 연동 로직 스켈레톤입니다.
   */
  const handlePurchase = async () => {
    if (!selectedPkg) return;
    setIsPurchasing(true);

    try {
      // ── 포트원 SDK 연동 (실제 구현 시 아래 주석 해제) ──────────────────────
      // const { IMP } = require('iamport-react-native');
      // IMP.init(config.PORTONE_IMP_CODE);
      // const response = await new Promise((resolve, reject) => {
      //   IMP.request_pay(
      //     {
      //       pg: config.PORTONE_PG_PROVIDER,
      //       pay_method: 'card',
      //       merchant_uid: `uria_coin_${Date.now()}`,
      //       name: selectedPkg.label,
      //       amount: selectedPkg.priceKRW,
      //       buyer_name: profile?.nickname,
      //     },
      //     (rsp: any) => {
      //       if (rsp.success) resolve(rsp);
      //       else reject(new Error(rsp.error_msg));
      //     },
      //   );
      // });
      // const { imp_uid } = response as any;
      // ────────────────────────────────────────────────────────────────────────

      // 개발/테스트 목적 임시 imp_uid
      const imp_uid = `test_imp_${Date.now()}`;

      const result = await coinsApi.purchase({
        packageId: selectedPkg.id,
        portonePaymentId: imp_uid,
      });

      updateCoinBalance(selectedPkg.coins + (selectedPkg.bonusCoins ?? 0));

      Alert.alert(
        '결제 완료',
        `${formatCoin(selectedPkg.coins + (selectedPkg.bonusCoins ?? 0))}이 충전되었습니다!\n현재 잔액: ${formatCoin(result.balance)}`,
        [{ text: '확인', onPress: () => navigation.goBack() }],
      );
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('결제 실패', getErrorMessage(err));
    } finally {
      setIsPurchasing(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* 현재 잔액 */}
        <View style={styles.balanceRow}>
          <Text style={styles.balanceLabel}>현재 잔액</Text>
          <Text style={styles.balanceValue}>
            {formatCoin(profile?.coinBalance ?? 0)}
          </Text>
        </View>

        {/* 패키지 그리드 */}
        <Text style={styles.sectionTitle}>코인 패키지 선택</Text>

        <View style={styles.packagesGrid}>
          {packages.map((pkg) => (
            <PackageCard
              key={pkg.id}
              pkg={pkg}
              isSelected={selectedPkg?.id === pkg.id}
              onSelect={() => setSelectedPkg(pkg)}
            />
          ))}
        </View>

        {/* 코인 사용처 안내 */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>코인 사용처</Text>
          {[
            '⚡ 기본 SIGNAL 전송: 1코인',
            '💎 프리미엄 SIGNAL 전송: 3코인',
            '코인은 유효기간이 없습니다',
            '구매 완료 후 환불 불가',
          ].map((line, i) => (
            <Text key={i} style={styles.infoLine}>
              {line}
            </Text>
          ))}
        </View>

        {/* 결제 버튼 */}
        <Button
          title={
            selectedPkg
              ? `${formatKRW(selectedPkg.priceKRW)} 결제하기`
              : '패키지를 선택하세요'
          }
          onPress={handlePurchase}
          isLoading={isPurchasing}
          disabled={!selectedPkg}
          fullWidth
          size="lg"
        />

        <Text style={styles.termsText}>
          결제 진행 시 이용약관 및 환불 정책에 동의하는 것으로 간주합니다.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, gap: 20, paddingBottom: 40 },

  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  balanceLabel: { fontSize: 14, color: colors.textMuted },
  balanceValue: { fontSize: 20, fontWeight: '800', color: colors.gold },

  sectionTitle: { fontSize: 15, fontWeight: '700', color: colors.text },

  packagesGrid: { flexDirection: 'row', gap: 10 },
  packageCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
    gap: 6,
    borderWidth: 2,
    borderColor: colors.border,
    position: 'relative',
  },
  packageCardSelected: {
    borderColor: colors.gold,
    backgroundColor: colors.goldAlpha10,
  },
  popularBadge: {
    position: 'absolute',
    top: -10,
    backgroundColor: colors.accent,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 999,
  },
  popularText: { fontSize: 10, color: colors.white, fontWeight: '700' },
  packageLabel: { fontSize: 12, color: colors.textFaint },
  packageCoins: { fontSize: 22, fontWeight: '900', color: colors.gold },
  packageBonus: { fontSize: 11, color: colors.green, fontWeight: '600' },
  packagePrice: { fontSize: 14, fontWeight: '700', color: colors.text },
  selectCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  selectCircleActive: { borderColor: colors.gold },
  selectDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.gold,
  },

  infoBox: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 14,
    padding: 16,
    gap: 6,
  },
  infoTitle: { fontSize: 13, fontWeight: '700', color: colors.textMuted, marginBottom: 4 },
  infoLine: { fontSize: 12, color: colors.textFaint, lineHeight: 18 },

  termsText: {
    fontSize: 11,
    color: colors.textFaint,
    textAlign: 'center',
    lineHeight: 16,
  },
});
