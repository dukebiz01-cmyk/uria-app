import React, { useEffect, useRef, useState } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Avatar } from '../common/Avatar';
import { SignalStatusBadge, TierBadge } from '../common/Badge';
import { Signal } from '../../types/api.types';
import { colors } from '../../constants/colors';
import { formatSignalCountdown, formatRelativeTime } from '../../utils/format';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface SignalCardProps {
  signal: Signal;
  direction: 'received' | 'sent';
  onPress?: () => void;
  onAccept?: () => void;
  onDecline?: () => void;
  onHold?: () => void;
}

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const SignalCard: React.FC<SignalCardProps> = ({
  signal,
  direction,
  onPress,
  onAccept,
  onDecline,
  onHold,
}) => {
  const [countdown, setCountdown] = useState(
    formatSignalCountdown(signal.expiresAt),
  );

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (signal.status !== 'pending') return;

    timerRef.current = setInterval(() => {
      setCountdown(formatSignalCountdown(signal.expiresAt));
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [signal.expiresAt, signal.status]);

  const user = direction === 'received' ? signal.fromUser : signal.toUser;
  const isPending = signal.status === 'pending';
  const isAccepted = signal.status === 'accepted';

  return (
    <TouchableOpacity
      style={[styles.card, isAccepted && styles.cardAccepted]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* 왼쪽 — 아바타 */}
      <Avatar
        uri={user.photos[0]}
        nickname={user.nickname}
        size="md"
      />

      {/* 중앙 — 정보 */}
      <View style={styles.info}>
        <View style={styles.nameRow}>
          <Text style={styles.nickname}>{user.nickname}</Text>
          <Text style={styles.age}> · {user.age}세</Text>
        </View>
        <TierBadge tier={user.passportTier} />

        {signal.message && (
          <Text style={styles.message} numberOfLines={2}>
            "{signal.message}"
          </Text>
        )}

        <Text style={styles.time}>
          {formatRelativeTime(signal.createdAt)}
        </Text>
      </View>

      {/* 오른쪽 — 상태 & 액션 */}
      <View style={styles.right}>
        <SignalStatusBadge status={signal.status} />

        {isPending && (
          <Text style={styles.countdown}>{countdown}</Text>
        )}

        {/* 받은 시그널이고 대기 중일 때 빠른 액션 버튼 */}
        {direction === 'received' && isPending && (
          <View style={styles.actions}>
            <TouchableOpacity
              style={[styles.actionBtn, styles.acceptBtn]}
              onPress={onAccept}
            >
              <Text style={styles.acceptText}>수락</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.declineBtn]}
              onPress={onDecline}
            >
              <Text style={styles.declineText}>거절</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    padding: 16,
    backgroundColor: colors.surface,
    borderRadius: 16,
    marginHorizontal: 16,
    marginVertical: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardAccepted: {
    borderColor: colors.greenAlpha10,
    backgroundColor: colors.surfaceAlt,
  },
  info: {
    flex: 1,
    gap: 4,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  nickname: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.text,
  },
  age: {
    fontSize: 13,
    color: colors.textMuted,
  },
  message: {
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 18,
    marginTop: 4,
    fontStyle: 'italic',
  },
  time: {
    fontSize: 11,
    color: colors.textFaint,
    marginTop: 4,
  },
  right: {
    alignItems: 'flex-end',
    gap: 6,
  },
  countdown: {
    fontSize: 11,
    color: colors.accent,
    fontWeight: '600',
    fontVariant: ['tabular-nums'],
  },
  actions: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 4,
  },
  actionBtn: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  acceptBtn: { backgroundColor: colors.greenAlpha10 },
  declineBtn: { backgroundColor: colors.accentAlpha10 },
  acceptText: { fontSize: 12, fontWeight: '600', color: colors.green },
  declineText: { fontSize: 12, fontWeight: '600', color: colors.accent },
});
