import React, { useRef, useState } from 'react';
import {
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { colors } from '../../constants/colors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface ChatInputProps {
  onSend: (text: string) => void;
  onImagePress?: () => void;
  isLoading?: boolean;
  placeholder?: string;
}

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const ChatInput: React.FC<ChatInputProps> = ({
  onSend,
  onImagePress,
  isLoading = false,
  placeholder = '메시지를 입력하세요...',
}) => {
  const [text, setText] = useState('');
  const inputRef = useRef<TextInput>(null);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;
    onSend(trimmed);
    setText('');
    inputRef.current?.clear();
  };

  const canSend = text.trim().length > 0 && !isLoading;

  return (
    <View style={styles.container}>
      {/* 이미지 첨부 */}
      {onImagePress && (
        <TouchableOpacity style={styles.iconButton} onPress={onImagePress}>
          {/* 아이콘: react-native-vector-icons 사용 */}
          {/* <Icon name="image" size={22} color={colors.textMuted} /> */}
          {/* 폴백 텍스트 버튼 */}
          {/* <Text style={styles.iconText}>📷</Text> */}
        </TouchableOpacity>
      )}

      {/* 텍스트 입력 */}
      <TextInput
        ref={inputRef}
        style={styles.input}
        value={text}
        onChangeText={setText}
        placeholder={placeholder}
        placeholderTextColor={colors.textFaint}
        multiline
        maxLength={500}
        selectionColor={colors.primary}
        onSubmitEditing={handleSend}
      />

      {/* 전송 버튼 */}
      <TouchableOpacity
        style={[styles.sendButton, canSend && styles.sendButtonActive]}
        onPress={handleSend}
        disabled={!canSend}
      >
        {/* <Icon name="send" size={18} color={canSend ? colors.white : colors.textFaint} /> */}
        {/* 폴백 */}
      </TouchableOpacity>
    </View>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    gap: 8,
  },
  iconButton: {
    width: 38,
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    minHeight: 38,
    maxHeight: 120,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 15,
    color: colors.text,
    lineHeight: 20,
  },
  sendButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonActive: {
    backgroundColor: colors.primary,
  },
  iconText: { fontSize: 20 },
});
