import { create } from 'zustand';
import { usersApi } from '../api/users.api';
import { passportApi } from '../api/passport.api';
import { UserProfile, Passport } from '../types/api.types';
import { parseApiError, getErrorMessage } from '../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface UserState {
  profile: UserProfile | null;
  passport: Passport | null;
  isLoading: boolean;
  error: string | null;
}

interface UserActions {
  fetchProfile: () => Promise<void>;
  fetchPassport: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => void; // 낙관적 업데이트
  setTonightMode: (active: boolean) => Promise<void>;
  updateCoinBalance: (delta: number) => void;
  reset: () => void;
}

type UserStore = UserState & UserActions;

// ─── 스토어 ───────────────────────────────────────────────────────────────────

export const useUserStore = create<UserStore>()((set, get) => ({
  profile: null,
  passport: null,
  isLoading: false,
  error: null,

  fetchProfile: async () => {
    set({ isLoading: true, error: null });
    try {
      const profile = await usersApi.getMe();
      set({ profile, isLoading: false });
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err), isLoading: false });
    }
  },

  fetchPassport: async () => {
    set({ isLoading: true, error: null });
    try {
      const passport = await passportApi.getMyPassport();
      set({ passport, isLoading: false });
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err), isLoading: false });
    }
  },

  updateProfile: (updates) => {
    const current = get().profile;
    if (!current) return;
    set({ profile: { ...current, ...updates } });
  },

  setTonightMode: async (active) => {
    const prev = get().profile;
    // 낙관적 업데이트
    if (prev) set({ profile: { ...prev, isTonightMode: active } });

    try {
      const updated = await usersApi.setTonightMode(active);
      set({ profile: updated });
    } catch (e) {
      // 롤백
      if (prev) set({ profile: prev });
      const err = parseApiError(e);
      set({ error: getErrorMessage(err) });
    }
  },

  updateCoinBalance: (delta) => {
    const current = get().profile;
    if (!current) return;
    set({
      profile: {
        ...current,
        coinBalance: Math.max(0, current.coinBalance + delta),
      },
    });
  },

  reset: () => set({ profile: null, passport: null, isLoading: false, error: null }),
}));
