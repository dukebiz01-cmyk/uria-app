import { useCallback, useState } from 'react';
import { Alert, Platform } from 'react-native';
import Geolocation, {
  GeoCoordinates,
  GeoError,
} from 'react-native-geolocation-service';
import { GeoPoint } from '../types/api.types';
import { config } from '../constants/config';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

export interface LocationResult {
  coords: GeoPoint;
  timestamp: number;
}

interface UseLocationReturn {
  location: LocationResult | null;
  isLoading: boolean;
  error: string | null;
  getCurrentLocation: () => Promise<LocationResult | null>;
  requestPermission: () => Promise<boolean>;
}

// ─── 훅 ──────────────────────────────────────────────────────────────────────

export function useLocation(): UseLocationReturn {
  const [location, setLocation] = useState<LocationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === 'ios') {
      const result = await Geolocation.requestAuthorization('whenInUse');
      return result === 'granted' || result === 'always';
    }

    if (Platform.OS === 'android') {
      // Android의 경우 PermissionsAndroid API 사용 (RN 내장)
      const { PermissionsAndroid } = await import('react-native');
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: '위치 권한 요청',
          message: 'TONIGHT MODE를 사용하려면 위치 정보 접근이 필요합니다.',
          buttonNeutral: '나중에',
          buttonNegative: '거부',
          buttonPositive: '허용',
        },
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    }

    return false;
  }, []);

  const getCurrentLocation = useCallback(async (): Promise<LocationResult | null> => {
    setIsLoading(true);
    setError(null);

    const hasPermission = await requestPermission();
    if (!hasPermission) {
      const msg = '위치 권한이 없습니다. 설정에서 위치 접근을 허용해주세요.';
      setError(msg);
      setIsLoading(false);

      Alert.alert('위치 권한 필요', msg, [
        { text: '취소', style: 'cancel' },
        {
          text: '설정 열기',
          onPress: () => {
            const { Linking } = require('react-native');
            if (Platform.OS === 'ios') {
              Linking.openURL('app-settings:');
            } else {
              Linking.openSettings();
            }
          },
        },
      ]);

      return null;
    }

    return new Promise((resolve) => {
      Geolocation.getCurrentPosition(
        (position: { coords: GeoCoordinates; timestamp: number }) => {
          const result: LocationResult = {
            coords: {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
              accuracyM: position.coords.accuracy ?? 0,
            },
            timestamp: position.timestamp,
          };
          setLocation(result);
          setIsLoading(false);
          resolve(result);
        },
        (geoError: GeoError) => {
          const msg = getLocationErrorMessage(geoError.code);
          setError(msg);
          setIsLoading(false);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: config.LOCATION_TIMEOUT,
          maximumAge: config.LOCATION_MAX_AGE,
          forceRequestLocation: true, // Android
          showLocationDialog: true,   // Android
        },
      );
    });
  }, [requestPermission]);

  return { location, isLoading, error, getCurrentLocation, requestPermission };
}

// ─── 에러 메시지 ──────────────────────────────────────────────────────────────

function getLocationErrorMessage(code: number): string {
  switch (code) {
    case 1:
      return '위치 접근이 거부되었습니다.';
    case 2:
      return 'GPS 신호를 받을 수 없습니다. 실외에서 다시 시도해주세요.';
    case 3:
      return '위치 정보 요청이 시간 초과되었습니다.';
    default:
      return '위치 정보를 가져올 수 없습니다.';
  }
}
