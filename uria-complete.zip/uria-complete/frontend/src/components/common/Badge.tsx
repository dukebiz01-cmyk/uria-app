import React from 'react';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors } from '../../constants/colors';
import { PassportTier, SignalStatus } from '../../types/api.types';

// ─── 공용 Badge ───────────────────────────────────────────────────────────────

interface BadgeProps {
  label: string;
  color?: string;
  backgroundColor?: string;
  size?: 'sm' | 'md';
  style?: ViewStyle;
}

export const Badge: React.FC<BadgeProps> = ({
  label,
  color = colors.text,
  backgroundColor = colors.surfaceAlt,
  size = 'sm',
  style,
}) => {
  const isSmall = size === 'sm';
  return (
    <View
      style={[
        styles.badge,
        isSmall ? styles.badgeSm : styles.badgeMd,
        { backgroundColor },
        style,
      ]}
    >
      <Text
        style={[
          styles.badgeText,
          isSmall ? styles.textSm : styles.textMd,
          { color },
        ]}
      >
        {label}
      </Text>
    </View>
  );
};

// ─── Signal 상태 Badge ────────────────────────────────────────────────────────

const SIGNAL_STATUS_MAP: Record<
  SignalStatus,
  { label: string; color: string; bg: string }
> = {
  pending: { label: '대기 중', color: colors.gold, bg: colors.goldAlpha10 },
  accepted: { label: '수락됨', color: colors.green, bg: colors.greenAlpha10 },
  declined: { label: '거절됨', color: colors.error, bg: colors.accentAlpha10 },
  hold: { label: '보류', color: colors.textMuted, bg: colors.surfaceAlt },
  expired: { label: '만료됨', color: colors.textFaint, bg: colors.surfaceAlt },
};

interface SignalStatusBadgeProps {
  status: SignalStatus;
  style?: ViewStyle;
}

export const SignalStatusBadge: React.FC<SignalStatusBadgeProps> = ({
  status,
  style,
}) => {
  const { label, color, bg } = SIGNAL_STATUS_MAP[status];
  return (
    <Badge label={label} color={color} backgroundColor={bg} style={style} />
  );
};

// ─── Passport Tier Badge ──────────────────────────────────────────────────────

const TIER_MAP: Record<
  PassportTier,
  { label: string; color: string; bg: string }
> = {
  Starter: { label: 'Starter', color: colors.textMuted, bg: colors.surfaceAlt },
  Silver: { label: 'Silver', color: '#C0C0C0', bg: 'rgba(192,192,192,0.12)' },
  Gold: { label: 'Gold', color: colors.gold, bg: colors.goldAlpha10 },
  Platinum: { label: 'Platinum', color: colors.teal, bg: colors.tealAlpha10 },
};

interface TierBadgeProps {
  tier: PassportTier;
  size?: 'sm' | 'md';
  style?: ViewStyle;
}

export const TierBadge: React.FC<TierBadgeProps> = ({ tier, size = 'sm', style }) => {
  const { label, color, bg } = TIER_MAP[tier];
  return (
    <Badge
      label={label}
      color={color}
      backgroundColor={bg}
      size={size}
      style={style}
    />
  );
};

// ─── 코인 Badge ───────────────────────────────────────────────────────────────

interface CoinBadgeProps {
  amount: number;
  style?: ViewStyle;
}

export const CoinBadge: React.FC<CoinBadgeProps> = ({ amount, style }) => (
  <Badge
    label={`${amount}C`}
    color={colors.gold}
    backgroundColor={colors.goldAlpha10}
    style={style}
  />
);

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  badge: {
    borderRadius: 999,
    alignSelf: 'flex-start',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeSm: { paddingHorizontal: 8, paddingVertical: 3 },
  badgeMd: { paddingHorizontal: 12, paddingVertical: 5 },
  badgeText: { fontWeight: '600' },
  textSm: { fontSize: 11 },
  textMd: { fontSize: 13 },
});
