import React from 'react';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';
import FastImage from 'react-native-fast-image';
import { colors } from '../../constants/colors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface AvatarProps {
  uri?: string | null;
  nickname?: string;
  size?: AvatarSize;
  style?: ViewStyle;
  showOnlineIndicator?: boolean;
}

const SIZE_MAP: Record<AvatarSize, number> = {
  xs: 28,
  sm: 40,
  md: 52,
  lg: 72,
  xl: 100,
};

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const Avatar: React.FC<AvatarProps> = ({
  uri,
  nickname,
  size = 'md',
  style,
  showOnlineIndicator = false,
}) => {
  const dimension = SIZE_MAP[size];
  const fontSize = Math.round(dimension * 0.38);

  const initials = nickname
    ? nickname.slice(0, 1).toUpperCase()
    : '?';

  return (
    <View style={[{ width: dimension, height: dimension }, style]}>
      {uri ? (
        <FastImage
          source={{ uri, priority: FastImage.priority.normal }}
          style={[
            styles.image,
            { width: dimension, height: dimension, borderRadius: dimension / 2 },
          ]}
          resizeMode={FastImage.resizeMode.cover}
        />
      ) : (
        <View
          style={[
            styles.placeholder,
            {
              width: dimension,
              height: dimension,
              borderRadius: dimension / 2,
            },
          ]}
        >
          <Text style={[styles.initials, { fontSize }]}>{initials}</Text>
        </View>
      )}

      {showOnlineIndicator && (
        <View
          style={[
            styles.onlineIndicator,
            {
              width: dimension * 0.28,
              height: dimension * 0.28,
              borderRadius: dimension * 0.14,
              bottom: 0,
              right: 0,
            },
          ]}
        />
      )}
    </View>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  image: {
    // borderRadius는 인라인으로 적용
  },
  placeholder: {
    backgroundColor: colors.primaryAlpha20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  initials: {
    color: colors.primary,
    fontWeight: '700',
  },
  onlineIndicator: {
    position: 'absolute',
    backgroundColor: colors.green,
    borderWidth: 2,
    borderColor: colors.bg,
  },
});
