import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppStackParamList } from '../../navigation/AppNavigator';
import { momentsApi } from '../../api/moments.api';
import { useLocation } from '../../hooks/useLocation';
import { Button } from '../../components/common/Button';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { formatMomentTimer } from '../../utils/format';
import { parseApiError, getErrorMessage } from '../../utils/errors';
import { Moment, MomentStatus } from '../../types/api.types';
import { config } from '../../constants/config';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AppStackParamList, 'MomentCheckin'>;

const POLL_INTERVAL = 5000; // 5초 폴링
const TIMER_SECONDS = config.MOMENT_TIMER_MINUTES * 60;

// ─── 상태 설명 텍스트 ─────────────────────────────────────────────────────────

function getStatusDescription(status: MomentStatus, isMine: boolean): string {
  switch (status) {
    case 'requested':
    case 'accepted':
      return '상대방이 수락을 기다리고 있습니다...';
    case 'user_checked_in':
      return isMine
        ? '체크인 완료! 상대방을 기다리고 있습니다...'
        : '상대방이 체크인했습니다. 지금 체크인해주세요!';
    case 'partner_checked_in':
      return isMine
        ? '상대방이 체크인했습니다. 지금 체크인해주세요!'
        : '체크인 완료! 상대방을 기다리고 있습니다...';
    case 'both_checked_in':
    case 'completed':
      return '두 분 모두 체크인 완료! MOMENT가 완료되었습니다 🎉';
    case 'failed':
      return '시간 초과 또는 위치 불일치로 MOMENT가 실패했습니다.';
    case 'cancelled':
      return 'MOMENT가 취소되었습니다.';
    default:
      return '';
  }
}

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const MomentCheckinScreen: React.FC<Props> = ({ route, navigation }) => {
  const { momentId, roomId } = route.params;
  const myId = ''; // useAuthStore에서 가져옴; 여기선 생략

  const { getCurrentLocation, isLoading: isGpsLoading } = useLocation();

  const [moment, setMoment] = useState<Moment | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCheckinLoading, setIsCheckinLoading] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(TIMER_SECONDS);
  const [hasCheckedIn, setHasCheckedIn] = useState(false);

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 초기 MOMENT 로드
  useEffect(() => {
    const load = async () => {
      try {
        const result = await momentsApi.getMoment(momentId);
        setMoment(result);

        // 타이머 시작 (timerEndsAt이 있으면 남은 시간으로 시작)
        if (result.timerEndsAt) {
          const remaining = Math.max(
            0,
            Math.floor(
              (new Date(result.timerEndsAt).getTime() - Date.now()) / 1000,
            ),
          );
          setTimerSeconds(remaining);
          startTimer(remaining);
        }
      } catch (e) {
        const err = parseApiError(e);
        Alert.alert('오류', getErrorMessage(err));
        navigation.goBack();
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [momentId, navigation]);

  // 폴링 — 상대방 체크인 감지
  useEffect(() => {
    pollRef.current = setInterval(async () => {
      try {
        const result = await momentsApi.getMoment(momentId);
        setMoment(result);

        if (
          result.status === 'completed' ||
          result.status === 'both_checked_in'
        ) {
          stopPolling();
          stopTimer();

          setTimeout(() => {
            navigation.replace('MomentReview', { momentId });
          }, 2000);
        } else if (
          result.status === 'failed' ||
          result.status === 'cancelled'
        ) {
          stopPolling();
          stopTimer();
        }
      } catch {
        // 폴링 실패는 무시
      }
    }, POLL_INTERVAL);

    return () => stopPolling();
  }, [momentId, navigation]); // eslint-disable-line react-hooks/exhaustive-deps

  const startTimer = (seconds: number) => {
    timerRef.current = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          stopTimer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const stopPolling = () => {
    if (pollRef.current) clearInterval(pollRef.current);
  };

  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const handleCheckin = useCallback(async () => {
    setIsCheckinLoading(true);
    try {
      const loc = await getCurrentLocation();
      if (!loc) {
        Alert.alert('위치 오류', '위치 정보를 가져올 수 없습니다.');
        return;
      }

      const updated = await momentsApi.checkin(momentId, {
        lat: loc.coords.lat,
        lng: loc.coords.lng,
        accuracyM: loc.coords.accuracyM,
      });

      setMoment(updated);
      setHasCheckedIn(true);
    } catch (e) {
      const err = parseApiError(e);
      Alert.alert('체크인 실패', getErrorMessage(err));
    } finally {
      setIsCheckinLoading(false);
    }
  }, [momentId, getCurrentLocation]);

  const handleCancel = () => {
    Alert.alert('MOMENT 취소', 'MOMENT를 취소하시겠습니까?', [
      { text: '계속 진행', style: 'cancel' },
      {
        text: '취소',
        style: 'destructive',
        onPress: async () => {
          await momentsApi.cancelMoment(momentId).catch(() => {});
          navigation.goBack();
        },
      },
    ]);
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <Spinner />
      </SafeAreaView>
    );
  }

  if (!moment) return null;

  const isCompleted =
    moment.status === 'completed' || moment.status === 'both_checked_in';
  const isFailed =
    moment.status === 'failed' || moment.status === 'cancelled';

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.content}>
        {/* 타이머 */}
        <View style={styles.timerContainer}>
          <Text style={styles.timerLabel}>남은 시간</Text>
          <Text
            style={[
              styles.timer,
              timerSeconds < 60 && styles.timerWarning,
              isCompleted && styles.timerComplete,
            ]}
          >
            {isCompleted ? '완료!' : isFailed ? '만료' : formatMomentTimer(timerSeconds)}
          </Text>
        </View>

        {/* 상태 */}
        <View style={styles.statusCard}>
          <Text style={styles.statusEmoji}>
            {isCompleted ? '🎉' : isFailed ? '😢' : hasCheckedIn ? '✅' : '📍'}
          </Text>
          <Text style={styles.statusText}>
            {getStatusDescription(moment.status, !hasCheckedIn)}
          </Text>
        </View>

        {/* 정확도 안내 */}
        {!hasCheckedIn && !isFailed && (
          <View style={styles.accuracyBox}>
            <Text style={styles.accuracyText}>
              📡 체크인 시 GPS 정확도가 자동으로 포함됩니다.{'\n'}
              실외에서 더 정확한 위치를 가져올 수 있습니다.
            </Text>
          </View>
        )}

        {/* 양쪽 체크인 상태 */}
        <View style={styles.checkinsRow}>
          <View style={styles.checkinItem}>
            <Text style={styles.checkinIcon}>
              {moment.requesterCheckedIn ? '✅' : '⏳'}
            </Text>
            <Text style={styles.checkinLabel}>요청자</Text>
          </View>
          <View style={styles.checkinDivider} />
          <View style={styles.checkinItem}>
            <Text style={styles.checkinIcon}>
              {moment.targetCheckedIn ? '✅' : '⏳'}
            </Text>
            <Text style={styles.checkinLabel}>상대방</Text>
          </View>
        </View>

        {/* 체크인 버튼 */}
        {!hasCheckedIn && !isFailed && !isCompleted && (
          <Button
            title={isGpsLoading ? 'GPS 위치 확인 중...' : '📍 지금 체크인하기'}
            onPress={handleCheckin}
            isLoading={isCheckinLoading || isGpsLoading}
            fullWidth
            size="lg"
            style={styles.checkinBtn}
          />
        )}

        {/* 취소 */}
        {!isCompleted && !isFailed && (
          <Button
            title="MOMENT 취소"
            variant="ghost"
            onPress={handleCancel}
            fullWidth
          />
        )}

        {/* 완료 후 리뷰 버튼 */}
        {isCompleted && (
          <Button
            title="후기 작성하기"
            onPress={() => navigation.replace('MomentReview', { momentId })}
            fullWidth
            size="lg"
          />
        )}
      </View>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: {
    flex: 1,
    padding: 24,
    gap: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  timerContainer: { alignItems: 'center', gap: 6 },
  timerLabel: { fontSize: 13, color: colors.textFaint },
  timer: {
    fontSize: 52,
    fontWeight: '800',
    color: colors.teal,
    fontVariant: ['tabular-nums'],
  },
  timerWarning: { color: colors.accent },
  timerComplete: { color: colors.green, fontSize: 40 },

  statusCard: {
    width: '100%',
    backgroundColor: colors.surface,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  statusEmoji: { fontSize: 48 },
  statusText: {
    fontSize: 15,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 22,
  },

  accuracyBox: {
    width: '100%',
    backgroundColor: colors.surfaceAlt,
    borderRadius: 12,
    padding: 14,
  },
  accuracyText: {
    fontSize: 12,
    color: colors.textFaint,
    lineHeight: 18,
    textAlign: 'center',
  },

  checkinsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    width: '100%',
    justifyContent: 'center',
  },
  checkinItem: { alignItems: 'center', gap: 6, flex: 1 },
  checkinIcon: { fontSize: 30 },
  checkinLabel: { fontSize: 12, color: colors.textFaint },
  checkinDivider: { width: 1, height: 40, backgroundColor: colors.border },

  checkinBtn: { marginTop: 8 },
});
