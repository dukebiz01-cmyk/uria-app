import { create } from 'zustand';
import { signalsApi } from '../api/signals.api';
import { Signal, SignalStatus } from '../types/api.types';
import { parseApiError, getErrorMessage } from '../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

interface SignalState {
  received: Signal[];
  sent: Signal[];
  receivedTotal: number;
  sentTotal: number;
  receivedPage: number;
  sentPage: number;
  isLoadingReceived: boolean;
  isLoadingSent: boolean;
  error: string | null;
}

interface SignalActions {
  fetchReceived: (page?: number) => Promise<void>;
  fetchSent: (page?: number) => Promise<void>;
  loadMoreReceived: () => Promise<void>;
  loadMoreSent: () => Promise<void>;
  respondSignal: (
    signalId: string,
    action: 'accept' | 'decline' | 'hold',
  ) => Promise<void>;
  addReceivedSignal: (signal: Signal) => void; // WebSocket에서 실시간 추가
  updateSignalStatus: (signalId: string, status: SignalStatus) => void;
  reset: () => void;
}

type SignalStore = SignalState & SignalActions;

// ─── 스토어 ───────────────────────────────────────────────────────────────────

const PAGE_SIZE = 20;

export const useSignalStore = create<SignalStore>()((set, get) => ({
  received: [],
  sent: [],
  receivedTotal: 0,
  sentTotal: 0,
  receivedPage: 1,
  sentPage: 1,
  isLoadingReceived: false,
  isLoadingSent: false,
  error: null,

  fetchReceived: async (page = 1) => {
    set({ isLoadingReceived: true, error: null });
    try {
      const result = await signalsApi.getReceivedSignals(page, PAGE_SIZE);
      set({
        received: page === 1 ? result.items : [...get().received, ...result.items],
        receivedTotal: result.total,
        receivedPage: page,
        isLoadingReceived: false,
      });
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err), isLoadingReceived: false });
    }
  },

  fetchSent: async (page = 1) => {
    set({ isLoadingSent: true, error: null });
    try {
      const result = await signalsApi.getSentSignals(page, PAGE_SIZE);
      set({
        sent: page === 1 ? result.items : [...get().sent, ...result.items],
        sentTotal: result.total,
        sentPage: page,
        isLoadingSent: false,
      });
    } catch (e) {
      const err = parseApiError(e);
      set({ error: getErrorMessage(err), isLoadingSent: false });
    }
  },

  loadMoreReceived: async () => {
    const { receivedPage, receivedTotal, received, isLoadingReceived } = get();
    if (isLoadingReceived || received.length >= receivedTotal) return;
    await get().fetchReceived(receivedPage + 1);
  },

  loadMoreSent: async () => {
    const { sentPage, sentTotal, sent, isLoadingSent } = get();
    if (isLoadingSent || sent.length >= sentTotal) return;
    await get().fetchSent(sentPage + 1);
  },

  respondSignal: async (signalId, action) => {
    // 낙관적 업데이트
    get().updateSignalStatus(
      signalId,
      action === 'accept'
        ? 'accepted'
        : action === 'decline'
          ? 'declined'
          : 'hold',
    );

    try {
      const updated = await signalsApi.respondSignal(signalId, { action });
      set({
        received: get().received.map((s) =>
          s.id === signalId ? updated : s,
        ),
      });
    } catch (e) {
      // 롤백: 다시 pending으로
      get().updateSignalStatus(signalId, 'pending');
      const err = parseApiError(e);
      set({ error: getErrorMessage(err) });
      throw e;
    }
  },

  addReceivedSignal: (signal) => {
    set((state) => ({
      received: [signal, ...state.received],
      receivedTotal: state.receivedTotal + 1,
    }));
  },

  updateSignalStatus: (signalId, status) => {
    set((state) => ({
      received: state.received.map((s) =>
        s.id === signalId ? { ...s, status } : s,
      ),
      sent: state.sent.map((s) =>
        s.id === signalId ? { ...s, status } : s,
      ),
    }));
  },

  reset: () =>
    set({
      received: [],
      sent: [],
      receivedTotal: 0,
      sentTotal: 0,
      receivedPage: 1,
      sentPage: 1,
      error: null,
    }),
}));
