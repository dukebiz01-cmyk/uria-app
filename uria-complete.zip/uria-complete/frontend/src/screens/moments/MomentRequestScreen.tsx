// MomentRequestScreen은 ChatRoomScreen의 헤더 버튼에서 인라인으로 처리합니다.
// 별도 스크린이 필요한 경우 (예: 상세 설명이 필요한 모달) 아래 컴포넌트를 사용합니다.

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AppStackParamList } from '../../navigation/AppNavigator';
import { Button } from '../../components/common/Button';
import { colors } from '../../constants/colors';

type Props = NativeStackScreenProps<AppStackParamList, 'MomentCheckin'>;

export const MomentRequestScreen: React.FC<Props> = ({ navigation, route }) => {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.content}>
        <Text style={styles.emoji}>🌙</Text>
        <Text style={styles.title}>MOMENT 요청</Text>
        <Text style={styles.desc}>
          상대방에게 실제 만남을 요청합니다.{'\n'}
          두 분 모두 수락하면 30분 타이머가 시작되고,{'\n'}
          같은 위치에서 체크인해야 MOMENT가 완료됩니다.
        </Text>

        <View style={styles.ruleList}>
          {[
            '두 분 모두 30분 내에 체크인 필요',
            '위치 반경 100m 이내에서 체크인',
            '완료 시 Trust Score 상승',
          ].map((rule, i) => (
            <View key={i} style={styles.ruleItem}>
              <Text style={styles.ruleCheck}>✓</Text>
              <Text style={styles.ruleText}>{rule}</Text>
            </View>
          ))}
        </View>

        <Button
          title="체크인 화면으로"
          onPress={() => navigation.navigate('MomentCheckin', route.params)}
          fullWidth
          size="lg"
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: {
    flex: 1,
    padding: 28,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
  },
  emoji: { fontSize: 60 },
  title: { fontSize: 26, fontWeight: '800', color: colors.text },
  desc: {
    fontSize: 14,
    color: colors.textMuted,
    lineHeight: 22,
    textAlign: 'center',
  },
  ruleList: {
    width: '100%',
    gap: 10,
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
  },
  ruleItem: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  ruleCheck: { fontSize: 14, color: colors.green, fontWeight: '700' },
  ruleText: { fontSize: 13, color: colors.textMuted, flex: 1 },
});
