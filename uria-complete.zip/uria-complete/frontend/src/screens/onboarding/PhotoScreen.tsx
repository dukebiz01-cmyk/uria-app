import React, { useState } from 'react';
import {
  Alert,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import {
  launchImageLibrary,
  ImagePickerResponse,
} from 'react-native-image-picker';

import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { usersApi } from '../../api/users.api';
import { useUserStore } from '../../store/user.store';
import { Button } from '../../components/common/Button';
import { colors } from '../../constants/colors';
import { getErrorMessage, parseApiError } from '../../utils/errors';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = NativeStackScreenProps<AuthStackParamList, 'Photo'>;

const MAX_PHOTOS = 6;

// ─── 컴포넌트 ─────────────────────────────────────────────────────────────────

export const PhotoScreen: React.FC<Props> = ({ navigation: _navigation }) => {
  const [photos, setPhotos] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const updateProfile = useUserStore((s) => s.updateProfile);

  const handleAddPhoto = async () => {
    if (photos.length >= MAX_PHOTOS) return;

    const result: ImagePickerResponse = await launchImageLibrary({
      mediaType: 'photo',
      quality: 0.85,
      selectionLimit: MAX_PHOTOS - photos.length,
    });

    if (result.didCancel || !result.assets) return;

    for (const asset of result.assets) {
      if (!asset.uri) continue;
      setIsUploading(true);

      try {
        const formData = new FormData();
        formData.append('photo', {
          uri: asset.uri,
          type: asset.type ?? 'image/jpeg',
          name: asset.fileName ?? `photo_${Date.now()}.jpg`,
        } as unknown as Blob);

        const { url } = await usersApi.uploadPhoto(formData);
        setPhotos((prev) => [...prev, url]);
      } catch (e) {
        const err = parseApiError(e);
        Alert.alert('업로드 실패', getErrorMessage(err));
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleComplete = () => {
    if (photos.length === 0) {
      Alert.alert('사진 필요', '최소 1장의 사진을 업로드해주세요.');
      return;
    }
    // 프로필 사진 업데이트 (낙관적)
    updateProfile({ photos });
    // RootNavigator가 AppNavigator로 자동 전환 (isAuthenticated = true, profile 완성)
    // 온보딩 완료 플래그 저장
    // storage.setItem(storage.keys.ONBOARDING_DONE, 'true');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.step}>3 / 3</Text>
          <Text style={styles.title}>사진을 추가해주세요</Text>
          <Text style={styles.subtitle}>
            대표 사진이 상대에게 보입니다. 최대 {MAX_PHOTOS}장까지 추가할 수 있어요.
          </Text>
        </View>

        {/* 사진 그리드 */}
        <View style={styles.grid}>
          {Array.from({ length: MAX_PHOTOS }, (_, i) => {
            const uri = photos[i];
            return (
              <TouchableOpacity
                key={i}
                style={[styles.photoSlot, uri && styles.photoSlotFilled]}
                onPress={uri ? () => handleRemovePhoto(i) : handleAddPhoto}
                activeOpacity={0.8}
              >
                {uri ? (
                  <>
                    <Image source={{ uri }} style={styles.photoImage} />
                    <View style={styles.removeOverlay}>
                      <Text style={styles.removeText}>✕</Text>
                    </View>
                  </>
                ) : (
                  <Text style={styles.addIcon}>+</Text>
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={styles.hint}>
          첫 번째 사진이 대표 사진으로 사용됩니다. {'\n'}
          사진을 탭하면 삭제됩니다.
        </Text>

        <Button
          title={photos.length === 0 ? '사진 추가' : '완료'}
          onPress={photos.length === 0 ? handleAddPhoto : handleComplete}
          isLoading={isUploading}
          fullWidth
          size="lg"
        />
      </View>
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: {
    flex: 1,
    padding: 24,
    gap: 28,
    justifyContent: 'center',
  },
  header: { gap: 10 },
  step: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  title: { fontSize: 26, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 14, color: colors.textMuted, lineHeight: 21 },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  photoSlot: {
    width: '30%',
    aspectRatio: 0.75,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  photoSlotFilled: {
    borderStyle: 'solid',
    borderColor: colors.primary,
  },
  photoImage: { width: '100%', height: '100%' },
  removeOverlay: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  removeText: { fontSize: 12, color: colors.white, fontWeight: '700' },
  addIcon: { fontSize: 28, color: colors.textFaint },
  hint: {
    fontSize: 12,
    color: colors.textFaint,
    textAlign: 'center',
    lineHeight: 18,
  },
});
