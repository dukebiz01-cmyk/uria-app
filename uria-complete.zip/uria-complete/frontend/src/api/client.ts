import axios, {
  AxiosError,
  AxiosInstance,
  InternalAxiosRequestConfig,
} from 'axios';
import { storage } from '../utils/storage';
import { ApiError } from '../types/api.types';
import { config } from '../constants/config';

// ─── Axios 인스턴스 ────────────────────────────────────────────────────────────

const apiClient: AxiosInstance = axios.create({
  baseURL: config.API_BASE_URL,
  timeout: config.API_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// ─── 토큰 갱신 중복 방지 플래그 ──────────────────────────────────────────────

let isRefreshing = false;
let pendingRequests: Array<{
  resolve: (token: string) => void;
  reject: (err: unknown) => void;
}> = [];

function processPendingRequests(token: string | null, error?: unknown) {
  pendingRequests.forEach(({ resolve, reject }) => {
    if (token) resolve(token);
    else reject(error);
  });
  pendingRequests = [];
}

// ─── 요청 인터셉터: Authorization 헤더 주입 ───────────────────────────────────

apiClient.interceptors.request.use(
  async (requestConfig: InternalAxiosRequestConfig) => {
    const { accessToken } = await storage.getTokens();
    if (accessToken) {
      requestConfig.headers.Authorization = `Bearer ${accessToken}`;
    }
    return requestConfig;
  },
  (error) => Promise.reject(error),
);

// ─── 응답 인터셉터: 401 → 토큰 갱신 → 재시도 ────────────────────────────────

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & {
      _retry?: boolean;
    };

    if (error.response?.status !== 401 || originalRequest._retry) {
      return Promise.reject(normalizeError(error));
    }

    // 이미 토큰 갱신 중이면 대기열에 추가
    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        pendingRequests.push({
          resolve: (token: string) => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            resolve(apiClient(originalRequest));
          },
          reject,
        });
      });
    }

    originalRequest._retry = true;
    isRefreshing = true;

    try {
      const { refreshToken } = await storage.getTokens();

      if (!refreshToken) {
        throw new Error('No refresh token');
      }

      // refresh 엔드포인트는 인터셉터를 우회하기 위해 직접 호출
      const { data } = await axios.post(
        `${config.API_BASE_URL}/auth/refresh`,
        { refreshToken },
        { headers: { 'Content-Type': 'application/json' } },
      );

      const newAccessToken: string = data.data.accessToken;
      const newRefreshToken: string = data.data.refreshToken;

      await storage.saveTokens(newAccessToken, newRefreshToken);

      // 대기 중인 요청들 재시작
      processPendingRequests(newAccessToken);

      originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
      return apiClient(originalRequest);
    } catch (refreshError) {
      processPendingRequests(null, refreshError);
      await storage.clearTokens();

      // auth.store의 logout 액션을 호출하기 위해 이벤트 발행
      // (순환 의존성을 피하기 위해 동적 import 사용)
      try {
        const { useAuthStore } = await import('../store/auth.store');
        useAuthStore.getState().logout();
      } catch {
        // store 로드 실패 시 무시
      }

      return Promise.reject(normalizeError(refreshError));
    } finally {
      isRefreshing = false;
    }
  },
);

// ─── 에러 표준화 ──────────────────────────────────────────────────────────────

function normalizeError(error: unknown): ApiError {
  if (error instanceof AxiosError) {
    const data = error.response?.data as Record<string, unknown> | undefined;
    return {
      code:
        typeof data?.code === 'string'
          ? data.code
          : `HTTP_${error.response?.status ?? 0}`,
      message:
        typeof data?.message === 'string'
          ? data.message
          : error.message ?? '알 수 없는 오류',
      status: error.response?.status ?? 0,
    };
  }

  if (error instanceof Error) {
    return { code: 'UNKNOWN_ERROR', message: error.message, status: 0 };
  }

  return { code: 'UNKNOWN_ERROR', message: '알 수 없는 오류', status: 0 };
}

export default apiClient;
