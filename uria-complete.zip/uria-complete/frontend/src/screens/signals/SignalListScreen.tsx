import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';

import { AppStackParamList, TabParamList } from '../../navigation/AppNavigator';
import { useSignalStore } from '../../store/signal.store';
import { SignalCard } from '../../components/signal/SignalCard';
import { SignalActionSheet } from '../../components/signal/SignalActionSheet';
import { Spinner } from '../../components/common/LoadingOverlay';
import { colors } from '../../constants/colors';
import { Signal } from '../../types/api.types';

// ─── 타입 ─────────────────────────────────────────────────────────────────────

type Props = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, 'Signals'>,
  NativeStackScreenProps<AppStackParamList>
>;

// ─── 받은 SIGNAL 탭 ────────────────────────────────────────────────────────────

const ReceivedTab: React.FC<{
  onSignalPress: (signal: Signal) => void;
  onActionPress: (signal: Signal) => void;
}> = ({ onSignalPress, onActionPress }) => {
  const {
    received,
    isLoadingReceived,
    fetchReceived,
    loadMoreReceived,
    respondSignal,
  } = useSignalStore();

  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    fetchReceived(1);
  }, [fetchReceived]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchReceived(1);
    setIsRefreshing(false);
  };

  if (isLoadingReceived && received.length === 0) return <Spinner />;

  return (
    <FlatList
      data={received}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <SignalCard
          signal={item}
          direction="received"
          onPress={() => onSignalPress(item)}
          onAccept={() =>
            respondSignal(item.id, 'accept').catch(() =>
              Alert.alert('오류', '수락 처리에 실패했습니다.'),
            )
          }
          onDecline={() => {
            Alert.alert('거절', `${item.fromUser.nickname}님의 SIGNAL을 거절하시겠습니까?`, [
              { text: '취소', style: 'cancel' },
              {
                text: '거절',
                style: 'destructive',
                onPress: () =>
                  respondSignal(item.id, 'decline').catch(() =>
                    Alert.alert('오류', '처리에 실패했습니다.'),
                  ),
              },
            ]);
          }}
          onHold={() =>
            respondSignal(item.id, 'hold').catch(() =>
              Alert.alert('오류', '처리에 실패했습니다.'),
            )
          }
        />
      )}
      onEndReached={loadMoreReceived}
      onEndReachedThreshold={0.4}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={handleRefresh}
          tintColor={colors.primary}
        />
      }
      ListEmptyComponent={
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyEmoji}>📭</Text>
          <Text style={styles.emptyText}>받은 SIGNAL이 없습니다</Text>
        </View>
      }
      contentContainerStyle={styles.listContent}
    />
  );
};

// ─── 보낸 SIGNAL 탭 ────────────────────────────────────────────────────────────

const SentTab: React.FC<{
  onSignalPress: (signal: Signal) => void;
}> = ({ onSignalPress }) => {
  const { sent, isLoadingSent, fetchSent, loadMoreSent } = useSignalStore();
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    fetchSent(1);
  }, [fetchSent]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchSent(1);
    setIsRefreshing(false);
  };

  if (isLoadingSent && sent.length === 0) return <Spinner />;

  return (
    <FlatList
      data={sent}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <SignalCard
          signal={item}
          direction="sent"
          onPress={() => onSignalPress(item)}
        />
      )}
      onEndReached={loadMoreSent}
      onEndReachedThreshold={0.4}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={handleRefresh}
          tintColor={colors.primary}
        />
      }
      ListEmptyComponent={
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyEmoji}>📤</Text>
          <Text style={styles.emptyText}>보낸 SIGNAL이 없습니다</Text>
        </View>
      }
      contentContainerStyle={styles.listContent}
    />
  );
};

// ─── 메인 스크린 ──────────────────────────────────────────────────────────────

export const SignalListScreen: React.FC<Props> = ({ navigation }) => {
  const [tabIndex, setTabIndex] = useState(0);
  const [routes] = useState([
    { key: 'received', title: '받은 SIGNAL' },
    { key: 'sent', title: '보낸 SIGNAL' },
  ]);
  const [actionSheetSignal, setActionSheetSignal] = useState<Signal | null>(null);

  const respondSignal = useSignalStore((s) => s.respondSignal);

  const handleSignalPress = useCallback(
    (signal: Signal) => {
      (navigation as any).navigate('SignalDetail', { signalId: signal.id });
    },
    [navigation],
  );

  const renderScene = SceneMap({
    received: () => (
      <ReceivedTab
        onSignalPress={handleSignalPress}
        onActionPress={(signal) => setActionSheetSignal(signal)}
      />
    ),
    sent: () => <SentTab onSignalPress={handleSignalPress} />,
  });

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.title}>SIGNAL</Text>
      </View>

      <TabView
        navigationState={{ index: tabIndex, routes }}
        renderScene={renderScene}
        onIndexChange={setTabIndex}
        renderTabBar={(props) => (
          <TabBar
            {...props}
            style={styles.tabBar}
            indicatorStyle={styles.tabIndicator}
            labelStyle={styles.tabLabel}
            activeColor={colors.primary}
            inactiveColor={colors.textFaint}
          />
        )}
      />

      <SignalActionSheet
        visible={!!actionSheetSignal}
        signal={actionSheetSignal}
        onAccept={async () => {
          if (!actionSheetSignal) return;
          await respondSignal(actionSheetSignal.id, 'accept').catch(() =>
            Alert.alert('오류', '수락 처리에 실패했습니다.'),
          );
          setActionSheetSignal(null);
        }}
        onDecline={async () => {
          if (!actionSheetSignal) return;
          await respondSignal(actionSheetSignal.id, 'decline').catch(() =>
            Alert.alert('오류', '처리에 실패했습니다.'),
          );
          setActionSheetSignal(null);
        }}
        onHold={async () => {
          if (!actionSheetSignal) return;
          await respondSignal(actionSheetSignal.id, 'hold').catch(() =>
            Alert.alert('오류', '처리에 실패했습니다.'),
          );
          setActionSheetSignal(null);
        }}
        onClose={() => setActionSheetSignal(null)}
      />
    </SafeAreaView>
  );
};

// ─── 스타일 ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: { fontSize: 22, fontWeight: '800', color: colors.text },
  tabBar: { backgroundColor: colors.surface },
  tabIndicator: { backgroundColor: colors.primary, height: 2 },
  tabLabel: { fontSize: 13, fontWeight: '700' },
  listContent: { paddingVertical: 8, paddingBottom: 20, flexGrow: 1 },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 80,
    gap: 12,
  },
  emptyEmoji: { fontSize: 40 },
  emptyText: { fontSize: 15, color: colors.textMuted },
});
