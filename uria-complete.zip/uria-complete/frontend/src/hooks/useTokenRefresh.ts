import { useEffect, useRef } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { useAuthStore } from '../store/auth.store';

const TOKEN_REFRESH_INTERVAL = 10 * 60 * 1000; // 10분

/**
 * 액세스 토큰 자동 갱신 훅
 * - 앱 활성화 시 또는 인터벌로 토큰 상태 확인
 * - 실제 401 갱신은 Axios 인터셉터에서 처리하므로 여기서는 선제적 갱신
 */
export function useTokenRefresh() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const refreshTokens = useAuthStore((s) => s.refreshTokens);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const doRefresh = async () => {
    if (!isAuthenticated) return;
    await refreshTokens();
  };

  useEffect(() => {
    if (!isAuthenticated) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    // 주기적 갱신
    timerRef.current = setInterval(doRefresh, TOKEN_REFRESH_INTERVAL);

    // 앱 활성화 시 즉시 갱신 시도
    const handleAppState = (state: AppStateStatus) => {
      if (state === 'active') doRefresh();
    };

    const subscription = AppState.addEventListener('change', handleAppState);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      subscription.remove();
    };
  }, [isAuthenticated]); // eslint-disable-line react-hooks/exhaustive-deps
}
