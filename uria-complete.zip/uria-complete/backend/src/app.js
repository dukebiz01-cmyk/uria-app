import express from 'express';
import pinoHttp from 'pino-http';
import logger from './utils/logger.js';

// Routers
import authRouter from './modules/auth/auth.router.js';
import usersRouter from './modules/users/users.router.js';
import signalsRouter from './modules/signals/signals.router.js';
import chatRouter from './modules/chat/chat.router.js';
import momentsRouter from './modules/moments/moments.router.js';
import coinsRouter from './modules/coins/coins.router.js';
import passportRouter from './modules/passport/passport.router.js';
import reportsRouter from './modules/reports/reports.router.js';
import adminRouter from './modules/admin/admin.router.js';

// Middleware
import { errorHandler } from './middleware/errorHandler.js';

const app = express();

// ============================================================
// Body parsing
// Store raw body for webhook signature validation
// ============================================================
app.use((req, res, next) => {
  if (req.path === '/api/coins/webhook') {
    let raw = '';
    req.on('data', (chunk) => { raw += chunk; });
    req.on('end', () => {
      req.rawBody = raw;
      try {
        req.body = JSON.parse(raw);
      } catch {
        req.body = {};
      }
      next();
    });
  } else {
    next();
  }
});

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ============================================================
// HTTP Request logging (pino-http)
// ============================================================
app.use(
  pinoHttp({
    logger,
    customLogLevel: (req, res, err) => {
      if (err || res.statusCode >= 500) return 'error';
      if (res.statusCode >= 400) return 'warn';
      return 'info';
    },
    serializers: {
      req: (req) => ({
        method: req.method,
        url: req.url,
        userAgent: req.headers['user-agent'],
      }),
    },
    // Don't log health checks
    autoLogging: {
      ignore: (req) => req.url === '/health',
    },
  }),
);

// ============================================================
// Security headers (minimal, add helmet in production)
// ============================================================
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// ============================================================
// Health check
// ============================================================
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ============================================================
// API Routes
// ============================================================
app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/signals', signalsRouter);
app.use('/api/chat', chatRouter);
app.use('/api/moments', momentsRouter);
app.use('/api/coins', coinsRouter);
app.use('/api/passport', passportRouter);
app.use('/api/reports', reportsRouter);
app.use('/api/admin', adminRouter);

// ============================================================
// 404 handler
// ============================================================
app.use((req, res) => {
  res.status(404).json({
    code: 'NOT_FOUND',
    message: `Route ${req.method} ${req.path} not found`,
    status: 404,
  });
});

// ============================================================
// Global error handler (must be last)
// ============================================================
app.use(errorHandler);

export default app;
